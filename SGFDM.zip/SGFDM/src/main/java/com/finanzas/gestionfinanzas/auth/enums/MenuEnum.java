package com.finanzas.gestionfinanzas.auth.enums;

// Menús que el servicio de seguridad devuelve para GFINGRESO (aplicación 565).
// El nombre debe coincidir letra por letra con el que llega en listaMenu: el rol
// de Spring Security se arma como "ROLE_" + nombre (ver CustomAuthenticationProvider).
//
// Se validan los MENÚS y no los perfiles (FACCINT / JEFACCINT) porque el servicio
// devuelve los menús que el usuario tiene asignados; el perfil es solo la forma en
// que se agrupan allá. Hoy FACCINT reúne FIFACT y FIREPO, y JEFACCINT suma FIAUDI
// y FIMANT, pero si mañana cambia ese reparto la aplicación no se entera ni hay
// que tocar nada.
public enum MenuEnum {
    FIFACT,  // Flujo Ingreso Factura     -> facturas, distribuciones e ingresos
    FIREPO,  // Flujo Ingreso Reporte     -> reportes y envíos
    FIAUDI,  // Flujo Ingreso Auditoría   -> auditoría
    FIMANT   // Flujo Ingreso Mantenimiento -> catálogos
}
