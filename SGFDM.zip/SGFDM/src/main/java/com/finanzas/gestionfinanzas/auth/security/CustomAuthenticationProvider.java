package com.finanzas.gestionfinanzas.auth.security;


import com.finanzas.gestionfinanzas.auth.dto.response.AplicacionDTO;
import com.finanzas.gestionfinanzas.auth.dto.response.AuthResponseDTO;
import com.finanzas.gestionfinanzas.auth.dto.response.MenuDTO;
import com.finanzas.gestionfinanzas.auth.enums.AppEnum;
import com.finanzas.gestionfinanzas.auth.service1.AuthService;

import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
public class CustomAuthenticationProvider implements AuthenticationProvider {

    private final AuthService authService;

    public CustomAuthenticationProvider(AuthService authService) {
        this.authService = authService;
    }

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {

        String username = authentication.getName();
        String password = authentication.getCredentials().toString();

        AuthResponseDTO user;
        try {
            user = authService.authenticate(username, password);

            Optional<AplicacionDTO> aplicacion = user.getListaAplicacion().stream().filter(e -> AppEnum.GFINGRESO.name().equals(e.getCodigo())).findFirst();

            if (!aplicacion.isPresent()) throw new BadCredentialsException("No tiene permisos para ingresar a este sistema");

            List<MenuDTO> permisos = authService.obtenerPerfilesUsuario(user.getId(), aplicacion.get().getId(), user.getToken());

            List<SimpleGrantedAuthority> authorities = new ArrayList<>();

            if (permisos != null && !permisos.isEmpty()) {
                authorities.addAll(permisos.stream()
                        .map(e -> new SimpleGrantedAuthority("ROLE_" + e.getNombre()))
                        .collect(Collectors.toList()));
            }

            authorities.add(new SimpleGrantedAuthority("ROLE_USER"));

            return new UsernamePasswordAuthenticationToken(user, null, authorities);

        } catch (BadCredentialsException e) {
            throw e;
        }
        catch (Exception e) {
            throw new AuthenticationServiceException(
                    "Error autenticando contra servicio externo",
                    e
            );
        }
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication);
    }
}
