package com.finanzas.gestionfinanzas.auth.security;

import com.finanzas.gestionfinanzas.auth.enums.MenuEnum;
import org.springframework.boot.web.servlet.ServletListenerRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.core.session.SessionRegistryImpl;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.session.HttpSessionEventPublisher;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final CustomAuthenticationProvider authProvider;
  //  private final CustomSuccessHandler customSuccessHandler;
    private final CustomAuthenticationFailureHandler customFailureHandler;

    public SecurityConfig(CustomAuthenticationProvider authProvider,
                          CustomAuthenticationFailureHandler customFailureHandler) {
       this.authProvider = authProvider;
       this.customFailureHandler = customFailureHandler;
    }

                        	  
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

        http
                .authenticationProvider(authProvider)
                .sessionManagement(session -> session
                        .maximumSessions(1)
                        .maxSessionsPreventsLogin(false)
                        .sessionRegistry(sessionRegistry())
                        .expiredUrl("/login?error=true&message=Se detecto un nuevo acceso desde otro dispositivo")
                )
             //   .authorizeRequests(auth -> auth
                  //      .antMatchers("/login", "/error", "/css/**", "/images/**", "/js/**", "/webjars/**", "/fonts/**").permitAll()
                        // Cada zona exige el menú que el servicio de seguridad le haya
                        // asignado al usuario. FIAUDI y FIMANT solo los trae JEFACCINT.
                    //    .antMatchers("/facturas-web", "/facturas-distribuciones", "/facturas/**",
                         //            "/guardar-distribuciones", "/detalle-distribucion/**",
                       //              "/ingresos", "/ingresos/**",
                       //              "/archivos/**").hasRole(MenuEnum.FIFACT.name())
                     .authorizeRequests(auth -> auth
        .antMatchers("/login", "/error", "/css/**", "/images/**", "/js/**", "/webjars/**", "/fonts/**").permitAll()
        // TEMPORAL: dejar pasar sin login mientras reviso algo — borrar esta línea después
        .antMatchers("/facturas-web").permitAll()
        .antMatchers("/facturas-web", "/facturas-distribuciones", "/facturas/**",
                     "/guardar-distribuciones", "/detalle-distribucion/**",
                     "/ingresos", "/ingresos/**",
                     "/archivos/**").hasRole(MenuEnum.FIFACT.name())
                       .antMatchers("/reportes", "/reportes/**",
                                     "/control-ingresos/**", "/envios/**").hasRole(MenuEnum.FIREPO.name())
                        .antMatchers("/auditoria", "/auditoria/**").hasRole(MenuEnum.FIAUDI.name())
                        .antMatchers("/mantenimiento", "/mantenimiento/**").hasRole(MenuEnum.FIMANT.name())
                     //   .anyRequest().authenticated()
                )
                .formLogin(form -> form
                        .loginPage("/login")
                        .loginProcessingUrl("/login")
                        .defaultSuccessUrl("/dashboard", true) // siempre va al dashboard
                        .failureHandler(customFailureHandler)
                        .permitAll()
                )

                .logout(logout -> logout
                        .logoutSuccessUrl("/login")
                );

        return http.build();
    }

    @Bean
    public SessionRegistry sessionRegistry() {
        return new SessionRegistryImpl();
    }

    @Bean
    public static ServletListenerRegistrationBean<HttpSessionEventPublisher>
    httpSessionEventPublisher() {

        return new ServletListenerRegistrationBean<>(
                new HttpSessionEventPublisher()
        );
    }
}
