package com.finanzas.gestionfinanzas;

import com.finanzas.gestionfinanzas.config.AppProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;


//import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
//import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
@EnableConfigurationProperties(AppProperties.class)
public class GestionFinanzasApplication extends SpringBootServletInitializer {
    public static void main(String[] args) {
        SpringApplication.run(GestionFinanzasApplication.class, args);
    }

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(GestionFinanzasApplication.class);
    }
}
