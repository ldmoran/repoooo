package com.finanzas.gestionfinanzas.auth.client.rest;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.finanzas.gestionfinanzas.config.AppProperties;
import com.finanzas.gestionfinanzas.auth.dto.response.AuthResponseDTO;
import com.finanzas.gestionfinanzas.auth.dto.response.SistemaResponseDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Component
public class AuthRestClient {
    private static final Logger log = LoggerFactory.getLogger(AuthRestClient.class);

    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;
    private final AppProperties appProperties;

    public AuthRestClient(RestTemplate restTemplate, ObjectMapper objectMapper, AppProperties appProperties) {
        this.restTemplate = restTemplate;
        this.objectMapper = objectMapper;
        this.appProperties = appProperties;
    }

    public AuthResponseDTO login(String usuario, String clave) {

        String baseUrl = appProperties.getServicios().getServidorWeblogicUrl();
        String url = baseUrl + "eppec-seguridad-ws/webresources/usuario/publico/obtenerPorCredenciales";

        Map<String, String> request = new HashMap<>();
        request.put("usuario", usuario);
        request.put("clave", clave);

        try {
            log.info("Autenticando usuario '{}' contra servicio externo: {}", usuario, url);

            ResponseEntity<AuthResponseDTO> response =
                    restTemplate.postForEntity(url, request, AuthResponseDTO.class);

            log.info("Respuesta autenticacion HTTP {} para usuario '{}'",
                    response.getStatusCodeValue(),
                    usuario);
            logAuthResponse(usuario, response.getBody());

            return response.getBody();

        } catch (HttpStatusCodeException ex) {

            try {
                String body = ex.getResponseBodyAsString();
                log.error("Error HTTP autenticando usuario '{}'. URL: {}. Status: {}. Body: {}",
                        usuario,
                        url,
                        ex.getStatusCode(),
                        body,
                        ex);

                return objectMapper.readValue(body, AuthResponseDTO.class);

            } catch (Exception e) {
                log.error("No se pudo procesar respuesta de autenticacion para usuario '{}'. URL: {}",
                        usuario,
                        url,
                        e);
                throw new RuntimeException("Error procesando respuesta del service");
            }
        } catch (Exception ex) {
            log.error("Error consumiendo servicio de autenticacion para usuario '{}'. URL: {}",
                    usuario,
                    url,
                    ex);
            throw ex;
        }
    }

    public SistemaResponseDTO obtenerPerfiles(String idUsuario, String idAplicacion, String token) {

        String baseUrl = appProperties.getServicios().getServidorWeblogicUrl();
        String url = baseUrl + "eppec-seguridad-ws/webresources/menu/listarPorSistemaUsuario";

        Map<String, String> request = new HashMap<>();
        request.put("id", idUsuario);
        request.put("idAplicacion", idAplicacion);

        HttpHeaders headers = new HttpHeaders();

        headers.setContentType(MediaType.APPLICATION_JSON);

        headers.add("Authorization", token);

        HttpEntity<Map<String, String>> entity =
                new HttpEntity<>(request, headers);

        try {

            log.info("Consultando perfiles usuario '{}', aplicacion '{}'. URL: {}. Token presente: {}",
                    idUsuario,
                    idAplicacion,
                    url,
                    token != null && !token.trim().isEmpty());

            ResponseEntity<SistemaResponseDTO> response =
                    restTemplate.exchange(
                            url,
                            HttpMethod.POST,
                            entity,
                            SistemaResponseDTO.class
                    );

            log.info("Respuesta perfiles HTTP {} para usuario '{}': {}",
                    response.getStatusCodeValue(),
                    idUsuario,
                    response.getBody());
            logPerfilesResponse(idUsuario, idAplicacion, response.getBody());

            return response.getBody();

        } catch (HttpStatusCodeException ex) {

            try {

                String body = ex.getResponseBodyAsString();
                log.error("Error HTTP consultando perfiles usuario '{}'. URL: {}. Status: {}. Body: {}",
                        idUsuario,
                        url,
                        ex.getStatusCode(),
                        body,
                        ex);

                return objectMapper.readValue(body,
                        SistemaResponseDTO.class);

            } catch (Exception e) {
                log.error("No se pudo procesar respuesta de perfiles para usuario '{}'. URL: {}",
                        idUsuario,
                        url,
                        e);

                throw new RuntimeException(
                        "Error procesando respuesta del service"
                );
            }
        } catch (Exception ex) {
            log.error("Error consumiendo servicio de perfiles para usuario '{}'. URL: {}",
                    idUsuario,
                    url,
                    ex);
            throw ex;
        }
    }

    private void logAuthResponse(String usuario, AuthResponseDTO body) {
        if (body == null) {
            log.warn("Autenticacion usuario '{}': respuesta vacia", usuario);
            return;
        }

        String codigo = body.getRespuesta() != null ? body.getRespuesta().getCodigo() : null;
        String mensaje = body.getRespuesta() != null ? body.getRespuesta().getMensaje() : null;
        Boolean autenticado = body.getUsuarioLdap() != null ? body.getUsuarioLdap().isEsAutenticado() : null;
        int aplicaciones = body.getListaAplicacion() != null ? body.getListaAplicacion().size() : 0;

        log.info("Autenticacion usuario '{}': codigo='{}', mensaje='{}', usuarioLdap={}, esAutenticado={}, aplicaciones={}",
                usuario,
                codigo,
                mensaje,
                body.getUsuarioLdap() != null,
                autenticado,
                aplicaciones);
    }

    private void logPerfilesResponse(String idUsuario, String idAplicacion, SistemaResponseDTO body) {
        if (body == null) {
            log.warn("Perfiles usuario '{}', aplicacion '{}': respuesta vacia", idUsuario, idAplicacion);
            return;
        }

        String codigo = body.getRespuesta() != null ? body.getRespuesta().getCodigo() : null;
        String mensaje = body.getRespuesta() != null ? body.getRespuesta().getMensaje() : null;
        int totalMenus = body.getListaMenu() != null ? body.getListaMenu().size() : 0;

        log.info("Perfiles usuario '{}', aplicacion '{}': codigo='{}', mensaje='{}', totalMenus={}",
                idUsuario,
                idAplicacion,
                codigo,
                mensaje,
                totalMenus);

        if (body.getListaMenu() != null) {
            body.getListaMenu().forEach(menu ->
                    log.info("Menu recibido: id='{}', nombre='{}', idAplicacion='{}'",
                            menu.getId(),
                            menu.getNombre(),
                            menu.getIdAplicacion()));
        }
    }

}
