package com.finanzas.gestionfinanzas.auth.controller;

import com.finanzas.gestionfinanzas.auth.dto.response.AuthResponseDTO;
import com.finanzas.gestionfinanzas.config.AppProperties;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import javax.servlet.http.HttpServletRequest;

@Controller
public class AuthController {
    private final AppProperties appProperties;

    public AuthController(AppProperties appProperties) {
        this.appProperties = appProperties;
    }

    @GetMapping("/login")
    public String login(Model model) {
        model.addAttribute("cipherClave", appProperties.getSeguridad().getCipherClave());
        model.addAttribute("cipherVector", appProperties.getSeguridad().getCipherVector());
        return "login";
    }

    @GetMapping("/dashboard")
    public String dashboard(HttpServletRequest request,
                            Model model,
                            @AuthenticationPrincipal AuthResponseDTO user) {
        model.addAttribute("nombre", user.getNombre());

        // 👉 Aquí pasamos el path actual para que el menú no explote
        model.addAttribute("path", request.getRequestURI());

        return "dashboard";
    }
}
