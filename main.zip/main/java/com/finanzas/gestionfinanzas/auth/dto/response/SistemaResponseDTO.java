package com.finanzas.gestionfinanzas.auth.dto.response;


import java.util.List;

public class SistemaResponseDTO {
    private List<MenuDTO> listaMenu;
    private RespuestaDTO respuesta;

    public SistemaResponseDTO() {
    }

    public SistemaResponseDTO(List<MenuDTO> listaMenu, RespuestaDTO respuesta) {
        this.listaMenu = listaMenu;
        this.respuesta = respuesta;
    }

    public List<MenuDTO> getListaMenu() {
        return listaMenu;
    }

    public void setListaMenu(List<MenuDTO> listaMenu) {
        this.listaMenu = listaMenu;
    }

    public RespuestaDTO getRespuesta() {
        return respuesta;
    }

    public void setRespuesta(RespuestaDTO respuesta) {
        this.respuesta = respuesta;
    }
}
