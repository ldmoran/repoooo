package com.finanzas.gestionfinanzas.auth.dto.response;

import com.fasterxml.jackson.annotation.JsonAlias;

public class UsuarioLdapDTO {
    @JsonAlias({"esAutenticado", "autenticado"})
    private boolean esAutenticado;
    private String nombreCompleto;

    public UsuarioLdapDTO() {
    }

    public UsuarioLdapDTO(boolean esAutenticado, String nombreCompleto) {
        this.esAutenticado = esAutenticado;
        this.nombreCompleto = nombreCompleto;
    }

    public boolean isEsAutenticado() {
        return esAutenticado;
    }

    public void setEsAutenticado(boolean esAutenticado) {
        this.esAutenticado = esAutenticado;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }
}
