package com.finanzas.gestionfinanzas.auth.service.impl;

import com.finanzas.gestionfinanzas.auth.client.rest.AuthRestClient;
import com.finanzas.gestionfinanzas.auth.dto.response.AuthResponseDTO;
import com.finanzas.gestionfinanzas.auth.dto.response.MenuDTO;
import com.finanzas.gestionfinanzas.auth.dto.response.SistemaResponseDTO;
import com.finanzas.gestionfinanzas.auth.service1.AuthService;
import com.finanzas.gestionfinanzas.utils.EncryptUtil;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

@Service
public class AuthServiceImpl implements AuthService {
    private static final String PASSWORD_ENCRYPTED_PREFIX = "ENC:";
    private static final String PASSWORD_OBFUSCATED_PREFIX = "OBF:";

    private final AuthRestClient authRestClient;
    private final EncryptUtil encryptUtil;

    public AuthServiceImpl(AuthRestClient authRestClient, EncryptUtil encryptUtil) {
        this.authRestClient = authRestClient;
        this.encryptUtil = encryptUtil;
    }

    public AuthResponseDTO authenticate(String username, String password) throws Exception {
        String encriptPassword = prepararPassword(password);
        AuthResponseDTO response = authRestClient.login(username, encriptPassword);

        if (response == null ||
                response.getUsuarioLdap() == null ||
                !response.getUsuarioLdap().isEsAutenticado()) {

            String mensaje = "Usuario y/o contrasena incorrectos.";

            if (response != null && response.getRespuesta() != null) {
                mensaje = response.getRespuesta().getMensaje();
            }

            throw new BadCredentialsException(mensaje);
        }

        return response;
    }

    private String prepararPassword(String password) throws Exception {
        if (password != null && password.startsWith(PASSWORD_ENCRYPTED_PREFIX)) {
            return password.substring(PASSWORD_ENCRYPTED_PREFIX.length());
        }

        if (password != null && password.startsWith(PASSWORD_OBFUSCATED_PREFIX)) {
            return encryptUtil.encriptar(decodificarPasswordOfuscado(
                    password.substring(PASSWORD_OBFUSCATED_PREFIX.length())));
        }

        return encryptUtil.encriptar(password);
    }

    private String decodificarPasswordOfuscado(String valor) {
        String decoded = new String(Base64.getDecoder().decode(valor), StandardCharsets.UTF_8);
        return new StringBuilder(decoded).reverse().toString();
    }

    public List<MenuDTO> obtenerPerfilesUsuario(String idUsuario, String idAplicacion, String token) {
        SistemaResponseDTO response = authRestClient.obtenerPerfiles(idUsuario, idAplicacion, token);

        if (response == null ||
                response.getRespuesta() == null ||
                !Objects.equals(response.getRespuesta().getCodigo(), "1")) {

            String mensaje = "No se pudieron obtener los permisos del usuario.";

            if (response != null && response.getRespuesta() != null) {
                mensaje = response.getRespuesta().getMensaje();
            }

            if (mensaje != null && mensaje.toLowerCase().contains("no existe menu")) {
                return Collections.emptyList();
            }

            throw new BadCredentialsException(mensaje);
        }

        return response.getListaMenu();
    }
}
