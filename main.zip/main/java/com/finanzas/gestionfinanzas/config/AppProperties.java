package com.finanzas.gestionfinanzas.config;


import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "app")
public class AppProperties {

    private Seguridad seguridad;
    private Servicios servicios;

    public Seguridad getSeguridad() {
        return seguridad;
    }

    public void setSeguridad(Seguridad seguridad) {
        this.seguridad = seguridad;
    }

    public Servicios getServicios() {
        return servicios;
    }

    public void setServicios(Servicios servicios) {
        this.servicios = servicios;
    }

    public static class Seguridad {
        private String cipherClave;
        private String cipherVector;

        public String getCipherClave() {
            return cipherClave;
        }

        public void setCipherClave(String cipherClave) {
            this.cipherClave = cipherClave;
        }

        public String getCipherVector() {
            return cipherVector;
        }

        public void setCipherVector(String cipherVector) {
            this.cipherVector = cipherVector;
        }
    }

    public static class Servicios {
        private String servidorWeblogicUrl;

        public String getServidorWeblogicUrl() {
            return servidorWeblogicUrl;
        }

        public void setServidorWeblogicUrl(String servidorWeblogicUrl) {
            this.servidorWeblogicUrl = servidorWeblogicUrl;
        }
    }


}
