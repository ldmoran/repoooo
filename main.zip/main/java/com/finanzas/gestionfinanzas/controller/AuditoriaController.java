package com.finanzas.gestionfinanzas.controller;

import com.finanzas.gestionfinanzas.entity.Auditoria;
import com.finanzas.gestionfinanzas.repository.bdd.AuditoriaRepository;
import com.finanzas.gestionfinanzas.repository.bdd.UsuarioRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;

// Solo lectura: la tabla AUDITORIA la alimentan los triggers de Oracle
// (ver reset_bd.sql), no hay nada que crear/editar/eliminar desde acá.
@Controller
@RequestMapping("/auditoria")
public class AuditoriaController {

    private final AuditoriaRepository auditoriaRepository;
    private final UsuarioRepository usuarioRepository;

    public AuditoriaController(AuditoriaRepository auditoriaRepository,
                               UsuarioRepository usuarioRepository) {
        this.auditoriaRepository = auditoriaRepository;
        this.usuarioRepository = usuarioRepository;
    }

    @GetMapping
    public String listar(@RequestParam(defaultValue = "0") int page,
                         @RequestParam(required = false) String nombreTabla,
                         @RequestParam(required = false) String accion,
                         @RequestParam(required = false) String usuarioAccion,
                         HttpServletRequest request, Model model) {
        Page<Auditoria> auditoriaPage = auditoriaRepository.buscar(
                normalizar(nombreTabla), normalizar(accion), normalizar(usuarioAccion),
                PageRequest.of(page, 20));

        model.addAttribute("path", request.getRequestURI());
        model.addAttribute("auditoriaPage", auditoriaPage);
        model.addAttribute("nombresTabla", auditoriaRepository.findDistinctNombreTabla());
        model.addAttribute("nombreTabla", nombreTabla);
        model.addAttribute("accion", accion);
        model.addAttribute("usuarioAccion", usuarioAccion);
        return "auditoria";
    }

    // Ficha de la persona que aparece en una fila de la auditoría. Sale de lo que
    // el sistema guardó la última vez que esa persona inició sesión.
    @GetMapping("/usuario-fragment")
    public String usuarioFragment(@RequestParam String usuario, Model model) {
        model.addAttribute("usuarioConsultado", usuario);
        model.addAttribute("detalleUsuario", usuarioRepository.findByUsuario(usuario).orElse(null));
        return "fragments/usuario-detalle :: usuarioDetalleFragment";
    }

    private String normalizar(String valor) {
        if (valor == null) {
            return null;
        }
        String limpio = valor.trim();
        return limpio.isEmpty() ? null : limpio;
    }
}
