package com.finanzas.gestionfinanzas.controller;

import com.finanzas.gestionfinanzas.dto.NuevaDistribucionDTO;
import com.finanzas.gestionfinanzas.service.impl.DistribucionService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Controller
public class DistribucionController {

    private final DistribucionService distribucionService;

    public DistribucionController(DistribucionService distribucionService) {
        this.distribucionService = distribucionService;
    }

    @PostMapping("/guardar-distribuciones")
    public String guardarDistribuciones(@RequestParam Long idFactura,
                                        @RequestParam(required = false) List<String> detalles,
                                        @RequestParam(required = false, defaultValue = "false") boolean marcarParcial,
                                        @RequestParam(required = false) Integer page,
                                        @RequestParam(required = false) String ruc,
                                        @RequestParam(required = false) String numFactura,
                                        @RequestParam(required = false) String fecEmbarque,
                                        @RequestParam(required = false) String fecDeposito,
                                        @RequestParam(required = false) String fecFactura,
                                        @RequestParam(required = false, defaultValue = "facturas-web") String origen,
                                        RedirectAttributes redirectAttributes) {
        List<String> errores = new ArrayList<>();
        List<NuevaDistribucionDTO> nuevasDistribuciones = new ArrayList<>();

        if (detalles != null) {
            for (String detalle : detalles) {
                if (detalle == null || detalle.trim().isEmpty()) {
                    continue;
                }

                String[] partes = detalle.split("\\|", -1);
                if (partes.length < 2) {
                    continue;
                }

                try {
                    Long idHija = Long.valueOf(partes[0]);
                    Double volumen = Double.valueOf(partes[1]);

                    // Costos manuales (MEM/Ministerio) en formato "idTipoCosto:total,idTipoCosto:total"
                    Map<Long, Double> totalesManualPorTipoCosto = new LinkedHashMap<>();
                    if (partes.length >= 3 && !partes[2].trim().isEmpty()) {
                        for (String costo : partes[2].split(",")) {
                            String[] costoPartes = costo.trim().split(":");
                            if (costoPartes.length < 2 || costoPartes[0].trim().isEmpty()) {
                                continue;
                            }
                            totalesManualPorTipoCosto.put(
                                    Long.valueOf(costoPartes[0].trim()),
                                    Double.valueOf(costoPartes[1].trim()));
                        }
                    }

                    nuevasDistribuciones.add(new NuevaDistribucionDTO(idHija, volumen, totalesManualPorTipoCosto));
                } catch (Exception e) {
                    errores.add(e.getMessage() != null ? e.getMessage() : "No se pudo interpretar una de las distribuciones");
                }
            }
        }

        // Guardado atómico: si alguna distribución del lote es inválida, no se guarda
        // ninguna (evita el caso de que una se guarde y otra no cuando juntas superan
        // la cantidad de la factura).
        int guardados = 0;
        if (errores.isEmpty() && !nuevasDistribuciones.isEmpty()) {
            try {
                distribucionService.guardarLoteDetalleDistribucion(idFactura, nuevasDistribuciones, marcarParcial);
                guardados = nuevasDistribuciones.size();
            } catch (Exception e) {
                errores.add(e.getMessage() != null ? e.getMessage() : "No se pudo guardar el lote de distribuciones");
            }
        }

        redirectAttributes.addFlashAttribute("distribucionesGuardadas", guardados);
        if (!errores.isEmpty()) {
            redirectAttributes.addFlashAttribute("erroresDistribucion", errores);
        }

        // Desde el modal de "Distribuciones asociadas" (facturas-distribuciones) no hace
        // falta conservar filtros de búsqueda: esa pantalla no los usa como los de facturas-web.
        if ("facturas-distribuciones".equals(origen)) {
            return "redirect:/facturas-distribuciones";
        }

        UriComponentsBuilder redirectBuilder = UriComponentsBuilder.fromPath("/facturas-web");
        if (page != null) {
            redirectBuilder.queryParam("page", page);
        }
        agregarSiNoVacio(redirectBuilder, "ruc", ruc);
        agregarSiNoVacio(redirectBuilder, "numFactura", numFactura);
        agregarSiNoVacio(redirectBuilder, "fecEmbarque", fecEmbarque);
        agregarSiNoVacio(redirectBuilder, "fecDeposito", fecDeposito);
        agregarSiNoVacio(redirectBuilder, "fecFactura", fecFactura);

        return "redirect:" + redirectBuilder.build().encode().toUriString();
    }

    private void agregarSiNoVacio(UriComponentsBuilder builder, String nombre, String valor) {
        if (valor != null && !valor.trim().isEmpty()) {
            builder.queryParam(nombre, valor.trim());
        }
    }

    @PostMapping("/detalle-distribucion/{idDetalle}/editar-volumen")
    public String editarVolumen(@PathVariable Long idDetalle,
                                @RequestParam Double volumen,
                                RedirectAttributes redirectAttributes) {
        try {
            distribucionService.editarVolumen(idDetalle, volumen);
            redirectAttributes.addFlashAttribute("volumenActualizado", true);
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("erroresDistribucion",
                    Collections.singletonList(e.getMessage() != null ? e.getMessage() : "No se pudo actualizar el volumen"));
        }

        return "redirect:/facturas-distribuciones";
    }

    @PostMapping("/detalle-distribucion/{idDetalle}/eliminar")
    public String eliminarDetalle(@PathVariable Long idDetalle,
                                  RedirectAttributes redirectAttributes) {
        try {
            distribucionService.eliminarDetalle(idDetalle);
            redirectAttributes.addFlashAttribute("distribucionEliminada", true);
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("erroresDistribucion",
                    Collections.singletonList(e.getMessage() != null ? e.getMessage() : "No se pudo eliminar la distribución"));
        }

        return "redirect:/facturas-distribuciones";
    }
}
