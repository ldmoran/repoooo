//package com.finanzas.gestionfinanzas.controller;

//import com.finanzas.gestionfinanzas.entity.DetalleDistribucion;
//import com.finanzas.gestionfinanzas.service.impl.DistribucionService;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;

//import java.util.List;

//@Controller
//public class FacturaController {

  //  private final DistribucionService distribucionService;

  //  public FacturaController(DistribucionService distribucionService) {
   //     this.distribucionService = distribucionService;
   // }

    // Endpoint que devuelve solo el fragmento con las distribuciones detalle de una factura
  //  @GetMapping("/facturas/{id}/distribuciones-fragment")
   // public String distribucionesFragment(@PathVariable("id") Long id, Model model) {
   //     List<DetalleDistribucion> detalles = distribucionService.listarDetallePorFactura(id);
       // model.addAttribute("detalles", detalles);
     //   return "fragments/distribuciones :: distribucionesFragment";
   // }
//}
