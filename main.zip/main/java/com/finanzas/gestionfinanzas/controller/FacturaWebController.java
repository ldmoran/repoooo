package com.finanzas.gestionfinanzas.controller;

import com.finanzas.gestionfinanzas.dto.ArchivoResumenDTO;
import com.finanzas.gestionfinanzas.dto.CostoLineaIngresoDTO;
import com.finanzas.gestionfinanzas.dto.CrudoCostosDTO;
import com.finanzas.gestionfinanzas.dto.CuentaConsolidadaDTO;
import com.finanzas.gestionfinanzas.dto.CuentaIngresoDTO;
import com.finanzas.gestionfinanzas.dto.DetalleFacturaResumenDTO;
import com.finanzas.gestionfinanzas.dto.EntidadCostosDTO;
import com.finanzas.gestionfinanzas.dto.FacturaIngresoDTO;
import com.finanzas.gestionfinanzas.dto.FilaCostoFacturaDTO;
import com.finanzas.gestionfinanzas.dto.TipoDistribucionCostosDTO;
import com.finanzas.gestionfinanzas.entity.CostoFactura;
import com.finanzas.gestionfinanzas.entity.CrudoEntidad;
import com.finanzas.gestionfinanzas.entity.DetalleDistribucion;
import com.finanzas.gestionfinanzas.entity.DistribucionHija;
import com.finanzas.gestionfinanzas.entity.DistribucionPadre;
import com.finanzas.gestionfinanzas.entity.Factura;
import com.finanzas.gestionfinanzas.entity.FacturasBDD;
import com.finanzas.gestionfinanzas.entity.TipoArchivo;
import com.finanzas.gestionfinanzas.entity.TipoCosto;
import com.finanzas.gestionfinanzas.repository.bdd.ArchivoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.CostoFacturaRepository;
import com.finanzas.gestionfinanzas.repository.bdd.CostoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.CrudoEntidadRepository;
import com.finanzas.gestionfinanzas.repository.bdd.CrudoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.DetalleDistribucionRepository;
import com.finanzas.gestionfinanzas.repository.bdd.DistribucionHijaRepository;
import com.finanzas.gestionfinanzas.repository.bdd.FacturasBDDRepository;
import com.finanzas.gestionfinanzas.repository.bdd.TipoArchivoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.TipoCostoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.TipoDistribucionRepository;
import com.finanzas.gestionfinanzas.service.FacturaService;
import com.finanzas.gestionfinanzas.service.impl.CostoFacturaService;
import com.finanzas.gestionfinanzas.service.impl.EnvioEbsService;
import com.finanzas.gestionfinanzas.service.impl.FacturaTransferService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import com.finanzas.gestionfinanzas.entity.Ingreso;
import com.finanzas.gestionfinanzas.repository.bdd.IngresoRepository;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Controller
public class FacturaWebController {

    private static final String SESION_CLAVE_BUSQUEDA = "facturasBusquedaClave";
    private static final String SESION_IDS_BUSQUEDA = "facturasBusquedaIds";

    private final FacturaService facturaService;
    private final FacturaTransferService facturaTransferService;
    private final FacturasBDDRepository facturasBDDRepository;
    private final DetalleDistribucionRepository detalleDistribucionRepository;
    private final DistribucionHijaRepository hijaRepo;
    private final CrudoRepository crudoRepository;
    private final CrudoEntidadRepository crudoEntidadRepository;
    private final TipoDistribucionRepository tipoDistribucionRepository;
    private final TipoCostoRepository tipoCostoRepository;
    private final IngresoRepository ingresoRepository;
    private final CostoRepository costoRepository;
    private final CostoFacturaService costoFacturaService;
    private final CostoFacturaRepository costoFacturaRepository;
    private final EnvioEbsService envioEbsService;
    private final ArchivoRepository archivoRepository;
    private final TipoArchivoRepository tipoArchivoRepository;


    public FacturaWebController(FacturaService facturaService,
                                FacturaTransferService facturaTransferService,
                                FacturasBDDRepository facturasBDDRepository,
                                DetalleDistribucionRepository detalleDistribucionRepository,
                                DistribucionHijaRepository hijaRepo,
                                CrudoRepository crudoRepository,
                                CrudoEntidadRepository crudoEntidadRepository,
                                TipoDistribucionRepository tipoDistribucionRepository,
                                TipoCostoRepository tipoCostoRepository,
                                IngresoRepository ingresoRepository,
                                CostoRepository costoRepository,
                                CostoFacturaService costoFacturaService,
                                CostoFacturaRepository costoFacturaRepository,
                                EnvioEbsService envioEbsService,
                                ArchivoRepository archivoRepository,
                                TipoArchivoRepository tipoArchivoRepository) {
        this.facturaService = facturaService;
        this.facturaTransferService = facturaTransferService;
        this.facturasBDDRepository = facturasBDDRepository;
        this.detalleDistribucionRepository = detalleDistribucionRepository;
        this.hijaRepo = hijaRepo;
        this.crudoRepository = crudoRepository;
        this.crudoEntidadRepository = crudoEntidadRepository;
        this.tipoDistribucionRepository = tipoDistribucionRepository;
        this.tipoCostoRepository = tipoCostoRepository;
        this.ingresoRepository = ingresoRepository;
        this.costoRepository = costoRepository;
        this.costoFacturaService = costoFacturaService;
        this.costoFacturaRepository = costoFacturaRepository;
        this.envioEbsService = envioEbsService;
        this.archivoRepository = archivoRepository;
        this.tipoArchivoRepository = tipoArchivoRepository;
    }

    @GetMapping("/facturas-web")
    public String listarFacturas(@RequestParam(defaultValue = "0") int page,
                                 @RequestParam(required = false) String ruc,
                                 @RequestParam(required = false) String numFactura,
                                 @RequestParam(required = false) String fecEmbarque,
                                 @RequestParam(required = false) String fecDeposito,
                                 @RequestParam(required = false) String fecFactura,
                                 @RequestParam(required = false) String buscar,
                                 HttpServletRequest request,
                                 Model model) {

        String rucNorm = normalizar(ruc);
        String numFacturaNorm = normalizar(numFactura);
        String fecDepositoNorm = normalizar(fecDeposito);
        String fecFacturaNorm = normalizar(fecFactura);
        String fecEmbarqueInicio = normalizar(fecEmbarque);
        String fecEmbarqueFin = fecEmbarqueInicio != null ? calcularFinRango(fecEmbarqueInicio) : null;
        String fecDepositoFin = fecDepositoNorm != null ? calcularFinRango(fecDepositoNorm) : null;
        boolean busquedaPorEmbarque = fecEmbarqueInicio != null && fecEmbarqueFin != null;
        boolean busquedaPorDeposito = fecDepositoNorm != null && fecDepositoFin != null;
        boolean busquedaRealizada = busquedaPorEmbarque || busquedaPorDeposito;

        Page<FacturasBDD> facturasPage;

        if (busquedaRealizada) {
            List<Long> idsEncontrados = recuperarIdsDeSesion(request, buscar != null,
                    rucNorm, numFacturaNorm, fecEmbarqueInicio, fecDepositoNorm, fecFacturaNorm);

            if (idsEncontrados == null) {
                // Trae TODAS las facturas de la vista que caen en el rango y las sincroniza
                // completas a la tabla local FACTURAS (antes solo se guardaban las 5 de la
                // página actual). Lo que se muestra en pantalla sale de la tabla local.
                // Si viene Fecha Embarque se busca por ese rango (Depósito queda como filtro
                // exacto adicional); si no, se busca por rango de Fecha Depósito directamente.
                List<Factura> encontradas = busquedaPorEmbarque
                        ? facturaService.buscarTodasPorRangoEmbarque(
                                rucNorm, numFacturaNorm, fecEmbarqueInicio, fecEmbarqueFin, fecDepositoNorm, fecFacturaNorm)
                        : facturaService.buscarTodasPorRangoDeposito(
                                rucNorm, numFacturaNorm, fecDepositoNorm, fecDepositoFin, fecFacturaNorm);

                // Una factura con datos problemáticos no debe frenar la sincronización de las demás.
                for (Factura encontrada : encontradas) {
                    try {
                        facturaTransferService.guardarEnBDD(encontrada);
                    } catch (Exception e) {
                        // se ignora esta factura puntual y se sigue con el resto
                    }
                }

                idsEncontrados = encontradas.stream()
                        .map(Factura::getCustomerTrxId)
                        .filter(Objects::nonNull)
                        .collect(Collectors.toCollection(ArrayList::new));

                guardarIdsEnSesion(request, idsEncontrados,
                        rucNorm, numFacturaNorm, fecEmbarqueInicio, fecDepositoNorm, fecFacturaNorm);
            }

            facturasPage = idsEncontrados.isEmpty()
                    ? Page.empty(PageRequest.of(page, 5))
                    : paginarLocalPorCustomerTrxId(idsEncontrados, page);
        } else {
            facturasPage = Page.empty(PageRequest.of(page, 5));
        }

        model.addAttribute("facturasPage", facturasPage);
        model.addAttribute("path", request.getRequestURI());
        model.addAttribute("busquedaRealizada", busquedaRealizada);
        model.addAttribute("ruc", ruc);
        model.addAttribute("numFactura", numFactura);
        model.addAttribute("fecEmbarque", fecEmbarque);
        model.addAttribute("fecDeposito", fecDeposito);
        model.addAttribute("fecFactura", fecFactura);
        model.addAttribute("distribucionesHija", hijaRepo.findAllConDetalle());
        model.addAttribute("crudos", crudoRepository.findByEstadoOrderByNombreCrudoAsc("A"));
        model.addAttribute("tiposDistribucion", tipoDistribucionRepository.findByEstadoOrderByNombreTipoDistribucionAsc("A"));
        model.addAttribute("todosTiposCostoJson", construirTiposCostoJson());
        model.addAttribute("detallesPorFactura", construirDetallesPorFactura(facturasPage.getContent()));
        model.addAttribute("archivosPorFactura", construirArchivosPorFactura(facturasPage.getContent()));
        // Los adjuntos de factura son siempre Comprobante de Distribución: el combo
        // no debe ofrecer los demás tipos del catálogo.
        model.addAttribute("tiposArchivo",
                tipoArchivoRepository.findByNombreTipoArchivoAndEstado(TipoArchivo.COMPROBANTE_DISTRIBUCION, "A"));

        return "facturas";
    }

    // Archivos activos ya subidos, agrupados por factura, para mostrarlos de
    // solo lectura o permitir subir/reemplazar/eliminar según su estado.
    private Map<Long, List<ArchivoResumenDTO>> construirArchivosPorFactura(List<FacturasBDD> facturas) {
        List<Long> idsFactura = facturas.stream()
                .map(FacturasBDD::getIdFactura)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        if (idsFactura.isEmpty()) {
            return Collections.emptyMap();
        }

        return archivoRepository.findActivosResumenByFacturaIn(idsFactura).stream()
                .collect(Collectors.groupingBy(ArchivoResumenDTO::getIdFactura, LinkedHashMap::new, Collectors.toList()));
    }

    // Resumen (Crudo/Tipo/Distribución/Volumen/Costos) de lo ya guardado por factura,
    // para mostrarlo de solo lectura cuando la factura ya está Aprobada.
    private Map<Long, List<DetalleFacturaResumenDTO>> construirDetallesPorFactura(List<FacturasBDD> facturas) {
        List<Long> idsFactura = facturas.stream()
                .map(FacturasBDD::getIdFactura)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        if (idsFactura.isEmpty()) {
            return Collections.emptyMap();
        }

        List<DetalleDistribucion> detalles = detalleDistribucionRepository.findConDetalleByFacturaIn(idsFactura);
        if (detalles.isEmpty()) {
            return Collections.emptyMap();
        }

        List<Long> idsDetalle = detalles.stream()
                .map(DetalleDistribucion::getIdDetalle)
                .collect(Collectors.toList());

        Map<Long, String> costosPorDetalle = ingresoRepository.findByDetalleDistribucion_IdDetalleIn(idsDetalle).stream()
                .filter(i -> i.getDetalleDistribucion() != null && i.getTipoCosto() != null)
                .collect(Collectors.groupingBy(
                        i -> i.getDetalleDistribucion().getIdDetalle(),
                        LinkedHashMap::new,
                        Collectors.mapping(i -> i.getTipoCosto().getNombreCosto(), Collectors.joining(", "))));

        Map<Long, List<DetalleFacturaResumenDTO>> resultado = new LinkedHashMap<>();
        for (DetalleDistribucion detalle : detalles) {
            Long idFactura = detalle.getFactura() != null ? detalle.getFactura().getIdFactura() : null;
            if (idFactura == null) {
                continue;
            }

            DistribucionHija hija = detalle.getDistribucionHija();
            DistribucionPadre padre = hija != null ? hija.getDistribucionPadre() : null;

            String crudo = padre != null && padre.getCrudo() != null ? padre.getCrudo().getNombreCrudo() : "-";
            String tipo = padre != null && padre.getTipoDistribucion() != null
                    ? padre.getTipoDistribucion().getNombreTipoDistribucion() : "-";
            String distribucion = hija != null ? hija.getNombreCompleto() : "-";
            String costos = costosPorDetalle.getOrDefault(detalle.getIdDetalle(), "-");

            resultado.computeIfAbsent(idFactura, k -> new ArrayList<>())
                    .add(new DetalleFacturaResumenDTO(crudo, tipo, distribucion, detalle.getVolumen(), costos));
        }

        return resultado;
    }

    // La búsqueda por Fecha Embarque trae un rango de 7 días desde la fecha indicada
    // (ej. 20/07 -> 20/07 al 27/07), no solo el día exacto.
    private String calcularFinRango(String fechaInicio) {
        try {
            return LocalDate.parse(fechaInicio).plusDays(7).toString();
        } catch (DateTimeParseException e) {
            return null;
        }
    }

    // Oracle limita las listas de un IN(...) a 1000 elementos, y una búsqueda de 7 días
    // puede traer más de eso; se consulta por lotes y se pagina en memoria con lo ya
    // traído (el volumen manejado aquí es chico, no vale la pena una query más compleja).
    // Consultar la vista del ERP es lo lento de esta pantalla, y al moverse entre
    // páginas no hace falta repetirlo: los CUSTOMER_TRX_ID del rango buscado ya
    // quedaron sincronizados en la tabla local. Se recuerdan en la sesión y
    // cualquier página se arma leyendo solo FACTURAS. Se vuelve a la vista únicamente
    // al presionar Buscar (que es como se refrescan los datos) o si los filtros
    // cambiaron respecto a lo que hay guardado.
    @SuppressWarnings("unchecked")
    private List<Long> recuperarIdsDeSesion(HttpServletRequest request, boolean nuevaBusqueda, String... filtros) {
        if (nuevaBusqueda) {
            return null;
        }

        HttpSession sesion = request.getSession();
        if (!claveBusqueda(filtros).equals(sesion.getAttribute(SESION_CLAVE_BUSQUEDA))) {
            return null;
        }

        return (List<Long>) sesion.getAttribute(SESION_IDS_BUSQUEDA);
    }

    private void guardarIdsEnSesion(HttpServletRequest request, List<Long> ids, String... filtros) {
        HttpSession sesion = request.getSession();
        sesion.setAttribute(SESION_CLAVE_BUSQUEDA, claveBusqueda(filtros));
        sesion.setAttribute(SESION_IDS_BUSQUEDA, ids);
    }

    private String claveBusqueda(String... filtros) {
        StringBuilder clave = new StringBuilder();
        for (String filtro : filtros) {
            clave.append(filtro).append('|');
        }
        return clave.toString();
    }

    private Page<FacturasBDD> paginarLocalPorCustomerTrxId(List<Long> customerTrxIds, int page) {
        List<FacturasBDD> encontradas = new ArrayList<>();
        int tamanoLote = 900;

        for (int i = 0; i < customerTrxIds.size(); i += tamanoLote) {
            List<Long> lote = customerTrxIds.subList(i, Math.min(i + tamanoLote, customerTrxIds.size()));
            encontradas.addAll(facturasBDDRepository.findByCustomerTrxIdIn(lote));
        }

        // Una ronda Aprobada que quedó Parcial ya generó su siguiente ronda (ver
        // CostoFacturaService.guardarCostosFactura), así que no debe seguir
        // mostrándose aquí: solo se ve la ronda nueva/activa de esa factura.
        encontradas.removeIf(f -> "A".equalsIgnoreCase(f.getEstado()) && "P".equals(f.getEstadoParcial()));

        encontradas.sort(Comparator.comparing(FacturasBDD::getIdFactura, Comparator.nullsLast(Comparator.reverseOrder())));

        int tamanoPagina = 5;
        int total = encontradas.size();
        int desde = Math.min(page * tamanoPagina, total);
        int hasta = Math.min(desde + tamanoPagina, total);

        return new PageImpl<>(encontradas.subList(desde, hasta), PageRequest.of(page, tamanoPagina), total);
    }

    private List<Map<String, Object>> construirTiposCostoJson() {
        List<Map<String, Object>> resultado = new ArrayList<>();

        for (TipoCosto tc : tipoCostoRepository.findAllConCrudo()) {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("id", tc.getIdTipoCosto());
            item.put("nombre", tc.getNombreCosto());
            item.put("idCrudo", tc.getCrudo() != null ? tc.getCrudo().getIdCrudo() : null);
            item.put("entidad", tc.getCrudoEntidad() != null ? tc.getCrudoEntidad().getNombreGrupo() : null);
            resultado.add(item);
        }

        return resultado;
    }

    @GetMapping("/facturas/{idFactura}/distribuciones-fragment")
    public String distribucionesFragment(@PathVariable Long idFactura, Model model) {
        List<DetalleDistribucion> detalles = detalleDistribucionRepository.findConDetalleByFactura(idFactura);

        Optional<FacturasBDD> facturaOpt = facturasBDDRepository.findById(idFactura);
        boolean aprobada = facturaOpt.map(f -> "A".equalsIgnoreCase(f.getEstado())).orElse(false);
        Double cantidad = facturaOpt.map(FacturasBDD::getCantidad).orElse(null);
        String estadoParcial = facturaOpt.map(FacturasBDD::getEstadoParcial).orElse(null);

        model.addAttribute("detallesDistribucion", detalles);
        model.addAttribute("idFactura", idFactura);
        model.addAttribute("aprobada", aprobada);
        model.addAttribute("cantidad", cantidad);
        model.addAttribute("estadoParcial", estadoParcial);
        // Para validar el volumen en el mismo campo, sin esperar a Guardar.
        model.addAttribute("volumenObjetivo", facturaOpt
                .map(f -> f.getVolumenTotal() != null
                        ? f.getVolumenTotal()
                        : (f.getCantidad() != null ? f.getCantidad().doubleValue() : null))
                .orElse(null));
        model.addAttribute("volumenDistribuido", facturaOpt
                .map(f -> f.getVolumenDistribuido() != null ? f.getVolumenDistribuido() : 0.0)
                .orElse(0.0));
        model.addAttribute("distribucionesHija", hijaRepo.findAllConDetalle());
        model.addAttribute("crudos", crudoRepository.findByEstadoOrderByNombreCrudoAsc("A"));
        model.addAttribute("tiposDistribucion", tipoDistribucionRepository.findByEstadoOrderByNombreTipoDistribucionAsc("A"));
        model.addAttribute("archivosFactura", archivoRepository.findActivosResumenByFactura(idFactura));
        // Los adjuntos de factura son siempre Comprobante de Distribución: el combo
        // no debe ofrecer los demás tipos del catálogo.
        model.addAttribute("tiposArchivo",
                tipoArchivoRepository.findByNombreTipoArchivoAndEstado(TipoArchivo.COMPROBANTE_DISTRIBUCION, "A"));

        return "fragments/distribuciones :: distribucionesFragment";
    }

@GetMapping("/facturas/{idFactura}/costos-fragment")
public String costosFragment(@PathVariable Long idFactura, Model model) {
    List<DetalleDistribucion> detalles = detalleDistribucionRepository.findConDetalleByFactura(idFactura);
    List<String> entidadesOrden = crudoEntidadRepository.findByEstadoOrderByIdGrupoAsc("A").stream()
            .map(CrudoEntidad::getNombreGrupo)
            .collect(Collectors.toList());

    List<EntidadCostosDTO> entidadesCostos = agruparCostosPorEntidad(detalles, entidadesOrden);

    double sumaTotal = entidadesCostos.stream()
            .flatMap(e -> e.getCrudos().stream())
            .flatMap(c -> c.getTipos().stream())
            .flatMap(t -> t.getFilas().stream())
            .mapToDouble(FilaCostoFacturaDTO::getTotal)
            .sum();

    model.addAttribute("entidadesCostos", entidadesCostos);
    model.addAttribute("distribucionesSinCosto", distribucionesSinCosto(detalles));
    model.addAttribute("sumaTotal", sumaTotal);
    model.addAttribute("idFactura", idFactura);

    return "fragments/costos-factura :: costosFacturaFragment";
}

// Las distribuciones de las que solo se registra el nombre (PARDALISERVICES, los
// IGAPO, los MEM cuyo valor aún no llega por oficio) no generan filas en INGRESOS,
// así que no entran en el agrupado por entidad: sin entidad ni tipo de costo no
// tienen dónde ubicarse. Se listan aparte para que los volúmenes cuadren con la
// cantidad de la factura y no parezca que falta algo justo antes de aprobar.
private List<FilaCostoFacturaDTO> distribucionesSinCosto(List<DetalleDistribucion> detalles) {
    if (detalles.isEmpty()) {
        return Collections.emptyList();
    }

    List<Long> idsDetalle = detalles.stream()
            .map(DetalleDistribucion::getIdDetalle)
            .collect(Collectors.toList());

    Set<Long> conCosto = ingresoRepository.findByDetalleDistribucion_IdDetalleIn(idsDetalle).stream()
            .filter(i -> i.getDetalleDistribucion() != null && i.getTipoCosto() != null)
            .map(i -> i.getDetalleDistribucion().getIdDetalle())
            .collect(Collectors.toSet());

    return detalles.stream()
            .filter(d -> !conCosto.contains(d.getIdDetalle()))
            .map(d -> new FilaCostoFacturaDTO(
                    d.getDistribucionHija() != null ? d.getDistribucionHija().getNombreCompleto() : "-",
                    Collections.emptyMap(),
                    d.getVolumen() != null ? d.getVolumen() : 0.0,
                    0.0))
            .collect(Collectors.toList());
}

@PostMapping("/facturas/{idFactura}/costos-guardar")
public String guardarCostosFactura(@PathVariable Long idFactura, RedirectAttributes redirectAttributes) {
    try {
        int guardados = costoFacturaService.guardarCostosFactura(idFactura);
        redirectAttributes.addFlashAttribute("costosGuardados", guardados);

        boolean quedoParcial = facturasBDDRepository.findById(idFactura)
                .map(f -> "P".equals(f.getEstadoParcial()))
                .orElse(false);
        redirectAttributes.addFlashAttribute("rondaCreada", quedoParcial);
    } catch (Exception e) {
        redirectAttributes.addFlashAttribute("errorCostos",
                e.getMessage() != null ? e.getMessage() : "No se pudo guardar los costos de la factura");
    }

    return "redirect:/facturas-distribuciones";
}

private static class FilaAcumulada {
    private final String nombreHija;
    private final double volumen;
    private final Map<String, Double> valoresPorCosto = new LinkedHashMap<>();

    private FilaAcumulada(String nombreHija, double volumen) {
        this.nombreHija = nombreHija;
        this.volumen = volumen;
    }
}

private List<EntidadCostosDTO> agruparCostosPorEntidad(List<DetalleDistribucion> detalles, List<String> entidadesOrden) {
    Map<String, Map<String, Map<String, Map<Long, FilaAcumulada>>>> acumulado = new LinkedHashMap<>();

    if (!detalles.isEmpty()) {
        List<Long> idsDetalle = detalles.stream()
                .map(DetalleDistribucion::getIdDetalle)
                .collect(Collectors.toList());

        Map<Long, DetalleDistribucion> detallesPorId = detalles.stream()
                .collect(Collectors.toMap(DetalleDistribucion::getIdDetalle, d -> d, (a, b) -> a));

        Map<Long, List<Ingreso>> ingresosPorDetalle = ingresoRepository.findByDetalleDistribucion_IdDetalleIn(idsDetalle).stream()
                .filter(i -> i.getDetalleDistribucion() != null && i.getTipoCosto() != null)
                .collect(Collectors.groupingBy(i -> i.getDetalleDistribucion().getIdDetalle(), LinkedHashMap::new, Collectors.toList()));

        List<Long> idsTipoCosto = ingresosPorDetalle.values().stream()
                .flatMap(List::stream)
                .map(i -> i.getTipoCosto().getIdTipoCosto())
                .distinct()
                .collect(Collectors.toList());

        // Mismo criterio que CostoFacturaService.guardarCostosFactura: un costo
        // INACTIVO (pendiente de comprobante) todavía no debe usarse para calcular
        // montos, o el preview mostraría un número distinto al que se guarda.
        Map<Long, Double> valorPorTipoCosto = costoRepository.findByTipoCosto_IdTipoCostoInAndEstado(idsTipoCosto, "ACTIVO").stream()
                .collect(Collectors.toMap(
                        c -> c.getTipoCosto().getIdTipoCosto(),
                        c -> c.getValor() != null ? c.getValor() : 0.0,
                        (a, b) -> a));

        for (Map.Entry<Long, List<Ingreso>> entry : ingresosPorDetalle.entrySet()) {
            Long idDetalle = entry.getKey();
            DetalleDistribucion detalle = detallesPorId.get(idDetalle);
            List<Ingreso> grupo = entry.getValue();

            DistribucionHija hija = detalle != null ? detalle.getDistribucionHija() : null;
            DistribucionPadre padre = hija != null ? hija.getDistribucionPadre() : null;

            String crudo = padre != null && padre.getCrudo() != null ? padre.getCrudo().getNombreCrudo() : "-";
            String tipoDistribucion = padre != null && padre.getTipoDistribucion() != null
                    ? padre.getTipoDistribucion().getNombreTipoDistribucion() : "-";
            String nombreHija = hija != null ? hija.getNombreCompleto() : "-";
            double volumen = detalle != null && detalle.getVolumen() != null ? detalle.getVolumen() : 0.0;

            for (Ingreso ingreso : grupo) {
                String entidad = ingreso.getTipoCosto().getCrudoEntidad() != null
                        ? ingreso.getTipoCosto().getCrudoEntidad().getNombreGrupo() : "Sin entidad";
                String nombreCosto = ingreso.getTipoCosto().getNombreCosto();
                // MEM/Ministerio: si el usuario tecleó el total a mano, ese valor manda
                // sobre el catálogo (misma regla que al aprobar, en CostoFacturaService).
                double total;
                if (ingreso.getTotalManual() != null) {
                    total = ingreso.getTotalManual();
                } else {
                    double valorCosto = valorPorTipoCosto.getOrDefault(ingreso.getTipoCosto().getIdTipoCosto(), 0.0);
                    total = valorCosto * volumen;
                }

                FilaAcumulada fila = acumulado
                        .computeIfAbsent(entidad, k -> new LinkedHashMap<>())
                        .computeIfAbsent(crudo, k -> new LinkedHashMap<>())
                        .computeIfAbsent(tipoDistribucion, k -> new LinkedHashMap<>())
                        .computeIfAbsent(idDetalle, k -> new FilaAcumulada(nombreHija, volumen));

                fila.valoresPorCosto.merge(nombreCosto, total, Double::sum);
            }
        }
    }

    List<String> ordenFinal = new ArrayList<>(entidadesOrden);
    for (String entidad : acumulado.keySet()) {
        if (!ordenFinal.contains(entidad)) {
            ordenFinal.add(entidad);
        }
    }

    List<EntidadCostosDTO> resultado = new ArrayList<>();
    for (String entidad : ordenFinal) {
        List<CrudoCostosDTO> crudos = new ArrayList<>();
        Map<String, Map<String, Map<Long, FilaAcumulada>>> porCrudo = acumulado.get(entidad);

        if (porCrudo != null) {
            for (Map.Entry<String, Map<String, Map<Long, FilaAcumulada>>> crudoEntry : porCrudo.entrySet()) {
                List<TipoDistribucionCostosDTO> tipos = new ArrayList<>();
                for (Map.Entry<String, Map<Long, FilaAcumulada>> tipoEntry : crudoEntry.getValue().entrySet()) {
                    Collection<FilaAcumulada> filasAcumuladas = tipoEntry.getValue().values();

                    Set<String> columnas = new LinkedHashSet<>();
                    for (FilaAcumulada fa : filasAcumuladas) {
                        columnas.addAll(fa.valoresPorCosto.keySet());
                    }

                    List<FilaCostoFacturaDTO> filas = new ArrayList<>();
                    for (FilaAcumulada fa : filasAcumuladas) {
                        double total = fa.valoresPorCosto.values().stream().mapToDouble(Double::doubleValue).sum();
                        filas.add(new FilaCostoFacturaDTO(fa.nombreHija, fa.valoresPorCosto, fa.volumen, total));
                    }

                    tipos.add(new TipoDistribucionCostosDTO(tipoEntry.getKey(), new ArrayList<>(columnas), filas));
                }
                crudos.add(new CrudoCostosDTO(crudoEntry.getKey(), tipos));
            }
        }

        resultado.add(new EntidadCostosDTO(entidad, crudos));
    }

    return resultado;
}

@GetMapping("/facturas-distribuciones")
public String verFacturasDistribuciones(@RequestParam(defaultValue = "0") int page,
                                        @RequestParam(required = false) String ruc,
                                        @RequestParam(required = false) String numFactura,
                                        @RequestParam(required = false) String fecEmbarque,
                                        @RequestParam(required = false) String fecDeposito,
                                        @RequestParam(required = false) String fecFactura,
                                        HttpServletRequest request,
                                        Model model) {

    // Ya no se consulta la vista externa: esta pantalla solo trabaja con lo que
    // ya está registrado en nuestra propia tabla FACTURAS.
    // Las facturas ya Aprobadas ("A") se mueven a la pantalla de Ingresos y dejan
    // de aparecer aquí; esta pantalla solo debe mostrar las Registradas ("R").
    Page<FacturasBDD> facturasPage = facturasBDDRepository.buscar(
            normalizar(ruc),
            normalizar(numFactura),
            normalizar(fecEmbarque),
            normalizar(fecDeposito),
            normalizar(fecFactura),
            "R",
            PageRequest.of(page, 5)
    );

    model.addAttribute("facturasPage", facturasPage);
    model.addAttribute("path", request.getRequestURI());
    model.addAttribute("todosTiposCostoJson", construirTiposCostoJson());

    return "facturas-distribuciones";
}

@GetMapping("/ingresos")
public String verIngresos(@RequestParam(defaultValue = "0") int page,
                          @RequestParam(required = false) String ruc,
                          @RequestParam(required = false) String numFactura,
                          @RequestParam(required = false) String fecEmbarque,
                          @RequestParam(required = false) String fecDeposito,
                          @RequestParam(required = false) String fecFactura,
                          HttpServletRequest request,
                          Model model) {

    // Solo facturas ya Aprobadas ("A"): una vez guardados sus costos, la factura
    // pasa de "Ver distribuciones" a este listado de solo lectura.
    Page<FacturasBDD> facturasPage = facturasBDDRepository.buscar(
            normalizar(ruc),
            normalizar(numFactura),
            normalizar(fecEmbarque),
            normalizar(fecDeposito),
            normalizar(fecFactura),
            "A",
            PageRequest.of(page, 5)
    );

    model.addAttribute("facturasPage", facturasPage);
    model.addAttribute("path", request.getRequestURI());
    model.addAttribute("todosTiposCostoJson", construirTiposCostoJson());

    return "ingresos";
}

@PostMapping("/ingresos/generar")
public String generarIngreso(@RequestParam(required = false) List<Long> idsFactura, Model model) {
    model.addAttribute("facturasIngreso", construirIngresoPorFactura(idsFactura));
    return "fragments/ingreso-generado :: ingresoGeneradoFragment";
}

@PostMapping("/ingresos/preview-envio")
public String previewEnvioEbs(@RequestParam(required = false) List<Long> idsFactura, Model model) {
    List<CuentaConsolidadaDTO> cuentas = envioEbsService.previsualizarConsolidado(idsFactura);
    double totalGeneral = cuentas.stream().mapToDouble(CuentaConsolidadaDTO::getTotalRecolectado).sum();

    model.addAttribute("cuentasConsolidadas", cuentas);
    model.addAttribute("totalGeneralConsolidado", totalGeneral);
    model.addAttribute("idsFactura", idsFactura);
    return "fragments/envio-ebs-preview :: envioEbsPreviewFragment";
}

@PostMapping("/ingresos/guardar-envio")
@ResponseBody
public ResponseEntity<String> guardarEnvioEbs(@RequestParam(required = false) List<Long> idsFactura) {
    try {
        envioEbsService.guardarEnvio(idsFactura);
        return ResponseEntity.ok("OK");
    } catch (Exception e) {
        return ResponseEntity.badRequest().body(e.getMessage() != null ? e.getMessage() : "No se pudo guardar el envío a EBS");
    }
}

// Arma, por cada factura Aprobada seleccionada, el desglose de sus costos
// agrupados por CUENTA contable (usando el snapshot ya guardado en
// COSTOS_FACTURA al momento de aprobar, no los valores vigentes de COSTOS).
private List<FacturaIngresoDTO> construirIngresoPorFactura(List<Long> idsFactura) {
    if (idsFactura == null || idsFactura.isEmpty()) {
        return Collections.emptyList();
    }

    List<CostoFactura> costos = costoFacturaRepository.findConCuentaByFacturaIn(idsFactura);

    Map<Long, String> numFacturaPorId = new LinkedHashMap<>();
    Map<String, String> descripcionPorCuenta = new LinkedHashMap<>();
    Map<Long, Map<String, Map<String, Double>>> acumulado = new LinkedHashMap<>();

    for (CostoFactura cf : costos) {
        if (cf.getFactura() == null || cf.getTipoCosto() == null || cf.getTotal() == null) {
            continue;
        }

        Long idFactura = cf.getFactura().getIdFactura();
        numFacturaPorId.putIfAbsent(idFactura, cf.getFactura().getNumFactura());

        String numeroCuenta = cf.getTipoCosto().getCuenta() != null
                ? cf.getTipoCosto().getCuenta().getNumeroCuenta()
                : "Sin cuenta asignada";
        descripcionPorCuenta.putIfAbsent(numeroCuenta,
                cf.getTipoCosto().getCuenta() != null ? cf.getTipoCosto().getCuenta().getDescripcion() : null);

        acumulado.computeIfAbsent(idFactura, k -> new LinkedHashMap<>())
                .computeIfAbsent(numeroCuenta, k -> new LinkedHashMap<>())
                .merge(cf.getTipoCosto().getNombreCosto(), cf.getTotal(), Double::sum);
    }

    List<FacturaIngresoDTO> resultado = new ArrayList<>();
    for (Long idFactura : idsFactura) {
        Map<String, Map<String, Double>> porCuenta = acumulado.get(idFactura);

        List<CuentaIngresoDTO> cuentas = new ArrayList<>();
        double totalFactura = 0;

        if (porCuenta != null) {
            for (Map.Entry<String, Map<String, Double>> entradaCuenta : porCuenta.entrySet()) {
                List<CostoLineaIngresoDTO> lineas = new ArrayList<>();
                double subtotal = 0;

                for (Map.Entry<String, Double> linea : entradaCuenta.getValue().entrySet()) {
                    lineas.add(new CostoLineaIngresoDTO(linea.getKey(), linea.getValue()));
                    subtotal += linea.getValue();
                }

                cuentas.add(new CuentaIngresoDTO(entradaCuenta.getKey(), descripcionPorCuenta.get(entradaCuenta.getKey()), lineas, subtotal));
                totalFactura += subtotal;
            }
        }

        String numFactura = numFacturaPorId.get(idFactura);
        if (numFactura == null) {
            numFactura = facturasBDDRepository.findById(idFactura).map(FacturasBDD::getNumFactura).orElse("-");
        }

        resultado.add(new FacturaIngresoDTO(idFactura, numFactura, cuentas, totalFactura));
    }

    return resultado;
}

    private String normalizar(String valor) {
        if (valor == null) {
            return null;
        }

        String limpio = valor.trim();
        return limpio.isEmpty() ? null : limpio;
    }
}
