package com.finanzas.gestionfinanzas.controller;

import com.finanzas.gestionfinanzas.entity.Cuenta;
import com.finanzas.gestionfinanzas.repository.bdd.CuentaRepository;
import com.finanzas.gestionfinanzas.repository.bdd.TipoCostoRepository;
import com.finanzas.gestionfinanzas.service.impl.AuditoriaSessionService;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/mantenimiento/cuentas")
public class MantenimientoCuentaController {

    private final CuentaRepository cuentaRepository;
    private final TipoCostoRepository tipoCostoRepository;
    private final AuditoriaSessionService auditoriaSessionService;

    public MantenimientoCuentaController(CuentaRepository cuentaRepository,
                                         TipoCostoRepository tipoCostoRepository,
                                         AuditoriaSessionService auditoriaSessionService) {
        this.cuentaRepository = cuentaRepository;
        this.tipoCostoRepository = tipoCostoRepository;
        this.auditoriaSessionService = auditoriaSessionService;
    }

    @GetMapping
    public String listar(@RequestParam(defaultValue = "0") int page,
                         @RequestParam(required = false) String numero,
                         @RequestParam(required = false) String estado,
                         HttpServletRequest request, Model model) {
        Page<Cuenta> cuentasPage = cuentaRepository.buscar(normalizar(numero), normalizar(estado), PageRequest.of(page, 10));

        model.addAttribute("path", request.getRequestURI());
        model.addAttribute("cuentasPage", cuentasPage);
        model.addAttribute("numero", numero);
        model.addAttribute("estado", estado);
        return "mantenimiento/cuentas";
    }

    private String normalizar(String valor) {
        if (valor == null) {
            return null;
        }
        String limpio = valor.trim();
        return limpio.isEmpty() ? null : limpio;
    }

    @PostMapping("/guardar")
    @Transactional("secondTransactionManager")
    public String guardar(@RequestParam(required = false) Long idCuenta,
                          @RequestParam String numeroCuenta,
                          @RequestParam(required = false) String descripcion,
                          @RequestParam String estado,
                          RedirectAttributes redirectAttributes) {

        auditoriaSessionService.activarUsuarioActual();

        Cuenta cuenta = (idCuenta != null)
                ? cuentaRepository.findById(idCuenta).orElseThrow(() -> new RuntimeException("Cuenta no encontrada"))
                : new Cuenta();

        cuenta.setNumeroCuenta(numeroCuenta.trim());
        cuenta.setDescripcion(descripcion != null ? descripcion.trim() : null);
        cuenta.setEstado(estado);

        try {
            cuentaRepository.save(cuenta);
        } catch (DataIntegrityViolationException e) {
            redirectAttributes.addFlashAttribute("error", "Ya existe una cuenta con ese número");
            return "redirect:/mantenimiento/cuentas";
        }

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/cuentas";
    }

    @PostMapping("/eliminar/{idCuenta}")
    @Transactional("secondTransactionManager")
    public String eliminar(@PathVariable Long idCuenta, RedirectAttributes redirectAttributes) {
        auditoriaSessionService.activarUsuarioActual();

        if (tipoCostoRepository.existsByCuenta_IdCuenta(idCuenta)) {
            redirectAttributes.addFlashAttribute("error",
                    "Esta cuenta tiene tipos de costo asociados, no se puede eliminar");
            return "redirect:/mantenimiento/cuentas";
        }

        try {
            cuentaRepository.deleteById(idCuenta);
        } catch (DataIntegrityViolationException e) {
            redirectAttributes.addFlashAttribute("error", "No se puede eliminar: tiene registros asociados");
            return "redirect:/mantenimiento/cuentas";
        }

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/cuentas";
    }
}
