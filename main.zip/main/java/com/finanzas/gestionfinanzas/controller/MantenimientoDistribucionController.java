package com.finanzas.gestionfinanzas.controller;

import com.finanzas.gestionfinanzas.entity.Crudo;
import com.finanzas.gestionfinanzas.entity.DistribucionHija;
import com.finanzas.gestionfinanzas.entity.DistribucionPadre;
import com.finanzas.gestionfinanzas.entity.TipoDistribucion;
import com.finanzas.gestionfinanzas.repository.bdd.CrudoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.DetalleDistribucionRepository;
import com.finanzas.gestionfinanzas.repository.bdd.DistribucionHijaRepository;
import com.finanzas.gestionfinanzas.repository.bdd.DistribucionPadreRepository;
import com.finanzas.gestionfinanzas.repository.bdd.TipoDistribucionRepository;
import com.finanzas.gestionfinanzas.service.impl.AuditoriaSessionService;
import com.finanzas.gestionfinanzas.utils.SecurityUtils;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import java.text.Normalizer;
import java.time.LocalDateTime;
import java.util.List;

@Controller
@RequestMapping("/mantenimiento/distribuciones")
public class MantenimientoDistribucionController {

    private final DistribucionPadreRepository padreRepo;
    private final DistribucionHijaRepository hijaRepo;
    private final CrudoRepository crudoRepository;
    private final TipoDistribucionRepository tipoDistribucionRepository;
    private final DetalleDistribucionRepository detalleDistribucionRepository;
    private final AuditoriaSessionService auditoriaSessionService;

    public MantenimientoDistribucionController(DistribucionPadreRepository padreRepo,
                                               DistribucionHijaRepository hijaRepo,
                                               CrudoRepository crudoRepository,
                                               TipoDistribucionRepository tipoDistribucionRepository,
                                               DetalleDistribucionRepository detalleDistribucionRepository,
                                               AuditoriaSessionService auditoriaSessionService) {
        this.padreRepo = padreRepo;
        this.hijaRepo = hijaRepo;
        this.crudoRepository = crudoRepository;
        this.tipoDistribucionRepository = tipoDistribucionRepository;
        this.detalleDistribucionRepository = detalleDistribucionRepository;
        this.auditoriaSessionService = auditoriaSessionService;
    }

    @GetMapping
    @Transactional("secondTransactionManager")
    public String listar(@RequestParam(defaultValue = "0") int page,
                         @RequestParam(required = false) Long idCrudo,
                         @RequestParam(required = false) Long idTipoDistribucion,
                         @RequestParam(required = false) String texto,
                         HttpServletRequest request, Model model) {
        auditoriaSessionService.activarUsuarioActual();
        asegurarCodigosGenerados();

        Page<DistribucionHija> distribucionesPage =
                hijaRepo.buscar(idCrudo, idTipoDistribucion, normalizar(texto), PageRequest.of(page, 10));

        model.addAttribute("path", request.getRequestURI());
        model.addAttribute("distribucionesPage", distribucionesPage);
        model.addAttribute("crudos", crudoRepository.findByEstadoOrderByNombreCrudoAsc("A"));
        model.addAttribute("tiposDistribucion", tipoDistribucionRepository.findByEstadoOrderByNombreTipoDistribucionAsc("A"));
        model.addAttribute("idCrudo", idCrudo);
        model.addAttribute("idTipoDistribucion", idTipoDistribucion);
        model.addAttribute("texto", texto);
        return "mantenimiento/distribuciones";
    }

    private String normalizar(String valor) {
        if (valor == null) {
            return null;
        }
        String limpio = valor.trim();
        return limpio.isEmpty() ? null : limpio;
    }

    @PostMapping("/guardar")
    @Transactional("secondTransactionManager")
    public String guardar(@RequestParam(required = false) Long idDeta,
                          @RequestParam Long idCrudo,
                          @RequestParam Long idTipoDistribucion,
                          @RequestParam String nombreCompleto,
                          RedirectAttributes redirectAttributes) {

        auditoriaSessionService.activarUsuarioActual();

        String usuarioActual = obtenerUsuarioActual();

        DistribucionPadre padre = padreRepo.findByCrudo_IdCrudoAndTipoDistribucion_IdTipoDistribucion(idCrudo, idTipoDistribucion)
                .orElseGet(() -> {
                    Crudo crudo = crudoRepository.findById(idCrudo)
                            .orElseThrow(() -> new RuntimeException("Crudo no encontrado"));
                    TipoDistribucion tipoDistribucion = tipoDistribucionRepository.findById(idTipoDistribucion)
                            .orElseThrow(() -> new RuntimeException("Tipo de distribución no encontrado"));

                    DistribucionPadre nuevo = new DistribucionPadre();
                    nuevo.setCrudo(crudo);
                    nuevo.setTipoDistribucion(tipoDistribucion);
                    nuevo.setIdUsuarioCreacion(usuarioActual);
                    nuevo.setFechaCreacion(LocalDateTime.now());
                    return padreRepo.save(nuevo);
                });

        DistribucionHija hija = (idDeta != null)
                ? hijaRepo.findById(idDeta).orElseThrow(() -> new RuntimeException("Distribución no encontrada"))
                : new DistribucionHija();

        boolean esNueva = hija.getIdDeta() == null;

        hija.setDistribucionPadre(padre);
        hija.setNombreCompleto(nombreCompleto.trim());
        hija.setCodigo(generarCodigo(hija.getNombreCompleto(), hija.getIdDeta()));

        if (esNueva) {
            hija.setIdUsuarioCreacion(usuarioActual);
            hija.setFechaCreacion(LocalDateTime.now());
        }

        hijaRepo.save(hija);

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/distribuciones";
    }

    @PostMapping("/eliminar/{idDeta}")
    @Transactional("secondTransactionManager")
    public String eliminar(@PathVariable Long idDeta, RedirectAttributes redirectAttributes) {
        auditoriaSessionService.activarUsuarioActual();

        if (detalleDistribucionRepository.existsByDistribucionHija_IdDeta(idDeta)) {
            redirectAttributes.addFlashAttribute("error",
                    "Esta distribución tiene ingresos asociados, no se puede eliminar");
            return "redirect:/mantenimiento/distribuciones";
        }

        try {
            hijaRepo.deleteById(idDeta);
        } catch (DataIntegrityViolationException e) {
            redirectAttributes.addFlashAttribute("error", "No se puede eliminar: tiene registros asociados");
            return "redirect:/mantenimiento/distribuciones";
        }

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/distribuciones";
    }

    private String obtenerUsuarioActual() {
        return SecurityUtils.getUsuarioActual() != null
                ? SecurityUtils.getUsuarioActual().getUsuario()
                : null;
    }

    private void asegurarCodigosGenerados() {
        List<DistribucionHija> sinCodigo = hijaRepo.findByCodigoIsNull();
        for (DistribucionHija hija : sinCodigo) {
            hija.setCodigo(generarCodigo(hija.getNombreCompleto(), hija.getIdDeta()));
            hijaRepo.save(hija);
        }
    }

    /**
     * Genera un código corto y único a partir del nombre completo:
     * iniciales de las primeras palabras + el primer número que aparezca
     * en el nombre (útil porque muchos nombres solo se diferencian por
     * el número de bloque). Si aun así choca con uno existente, se le
     * agrega un sufijo numérico hasta que quede único.
     */
    private String generarCodigo(String nombreCompleto, Long idDetaActual) {
        String normalizado = Normalizer.normalize(nombreCompleto.toUpperCase(), Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "");
        String[] tokens = normalizado.split("[^A-Z0-9]+");

        StringBuilder iniciales = new StringBuilder();
        String numero = null;

        for (String token : tokens) {
            if (token.isEmpty()) {
                continue;
            }
            if (token.matches("\\d+")) {
                if (numero == null) {
                    numero = token;
                }
                continue;
            }
            if (iniciales.length() < 4) {
                iniciales.append(token.charAt(0));
            }
        }

        String base = numero != null ? iniciales.toString() + numero : iniciales.toString();
        if (base.isEmpty()) {
            base = "COD";
        }
        if (base.length() > 8) {
            base = base.substring(0, 8);
        }

        String candidato = base;
        int sufijo = 1;
        while (existeCodigo(candidato, idDetaActual)) {
            String numSufijo = String.format("%02d", sufijo);
            int maxBase = 10 - numSufijo.length();
            candidato = (base.length() > maxBase ? base.substring(0, maxBase) : base) + numSufijo;
            sufijo++;
        }
        return candidato;
    }

    private boolean existeCodigo(String codigo, Long idDetaActual) {
        return idDetaActual != null
                ? hijaRepo.existsByCodigoAndIdDetaNot(codigo, idDetaActual)
                : hijaRepo.existsByCodigo(codigo);
    }
}
