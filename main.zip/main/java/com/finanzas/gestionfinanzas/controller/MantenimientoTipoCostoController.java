package com.finanzas.gestionfinanzas.controller;

import com.finanzas.gestionfinanzas.entity.Crudo;
import com.finanzas.gestionfinanzas.entity.CrudoEntidad;
import com.finanzas.gestionfinanzas.entity.Cuenta;
import com.finanzas.gestionfinanzas.entity.TipoCosto;
import com.finanzas.gestionfinanzas.repository.bdd.CostoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.CrudoEntidadRepository;
import com.finanzas.gestionfinanzas.repository.bdd.CrudoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.CuentaRepository;
import com.finanzas.gestionfinanzas.repository.bdd.IngresoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.TipoCostoRepository;
import com.finanzas.gestionfinanzas.service.impl.AuditoriaSessionService;
import com.finanzas.gestionfinanzas.utils.SecurityUtils;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;

@Controller
@RequestMapping("/mantenimiento/tipos-costo")
public class MantenimientoTipoCostoController {

    private final TipoCostoRepository tipoCostoRepository;
    private final CrudoRepository crudoRepository;
    private final CrudoEntidadRepository crudoEntidadRepository;
    private final CuentaRepository cuentaRepository;
    private final CostoRepository costoRepository;
    private final IngresoRepository ingresoRepository;
    private final AuditoriaSessionService auditoriaSessionService;

    public MantenimientoTipoCostoController(TipoCostoRepository tipoCostoRepository,
                                            CrudoRepository crudoRepository,
                                            CrudoEntidadRepository crudoEntidadRepository,
                                            CuentaRepository cuentaRepository,
                                            CostoRepository costoRepository,
                                            IngresoRepository ingresoRepository,
                                            AuditoriaSessionService auditoriaSessionService) {
        this.tipoCostoRepository = tipoCostoRepository;
        this.crudoRepository = crudoRepository;
        this.crudoEntidadRepository = crudoEntidadRepository;
        this.cuentaRepository = cuentaRepository;
        this.costoRepository = costoRepository;
        this.ingresoRepository = ingresoRepository;
        this.auditoriaSessionService = auditoriaSessionService;
    }

    @GetMapping
    public String listar(@RequestParam(defaultValue = "0") int page,
                         @RequestParam(required = false) Long idCrudo,
                         @RequestParam(required = false) Long idGrupo,
                         @RequestParam(required = false) String nombreCosto,
                         HttpServletRequest request, Model model) {
        Page<TipoCosto> tiposCostoPage =
                tipoCostoRepository.buscar(idCrudo, idGrupo, normalizar(nombreCosto), PageRequest.of(page, 10));

        model.addAttribute("path", request.getRequestURI());
        model.addAttribute("tiposCostoPage", tiposCostoPage);
        model.addAttribute("crudos", crudoRepository.findByEstadoOrderByNombreCrudoAsc("A"));
        model.addAttribute("entidades", crudoEntidadRepository.findByEstadoOrderByNombreGrupoAsc("A"));
        model.addAttribute("cuentas", cuentaRepository.findByEstadoOrderByNumeroCuentaAsc("A"));
        model.addAttribute("idCrudo", idCrudo);
        model.addAttribute("idGrupo", idGrupo);
        model.addAttribute("nombreCosto", nombreCosto);
        return "mantenimiento/tipos-costo";
    }

    private String normalizar(String valor) {
        if (valor == null) {
            return null;
        }
        String limpio = valor.trim();
        return limpio.isEmpty() ? null : limpio;
    }

    @PostMapping("/guardar")
    @Transactional("secondTransactionManager")
    public String guardar(@RequestParam(required = false) Long idTipoCosto,
                          @RequestParam Long idCrudo,
                          @RequestParam(required = false) Long idGrupo,
                          @RequestParam(required = false) Long idCuenta,
                          @RequestParam String nombreCosto,
                          RedirectAttributes redirectAttributes) {

        auditoriaSessionService.activarUsuarioActual();

        Crudo crudo = crudoRepository.findById(idCrudo)
                .orElseThrow(() -> new RuntimeException("Crudo no encontrado"));

        CrudoEntidad crudoEntidad = (idGrupo != null)
                ? crudoEntidadRepository.findById(idGrupo).orElseThrow(() -> new RuntimeException("Entidad no encontrada"))
                : null;

        Cuenta cuenta = (idCuenta != null)
                ? cuentaRepository.findById(idCuenta).orElseThrow(() -> new RuntimeException("Cuenta no encontrada"))
                : null;

        TipoCosto tipoCosto = (idTipoCosto != null)
                ? tipoCostoRepository.findById(idTipoCosto).orElseThrow(() -> new RuntimeException("Tipo de costo no encontrado"))
                : new TipoCosto();

        boolean esNuevo = tipoCosto.getIdTipoCosto() == null;

        tipoCosto.setCrudo(crudo);
        tipoCosto.setCrudoEntidad(crudoEntidad);
        tipoCosto.setCuenta(cuenta);
        tipoCosto.setNombreCosto(nombreCosto.trim());

        if (esNuevo) {
            tipoCosto.setIdUsuarioCreacion(obtenerUsuarioActual());
            tipoCosto.setFechaCreacion(LocalDateTime.now());
        }

        tipoCostoRepository.save(tipoCosto);

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/tipos-costo";
    }

    @PostMapping("/eliminar/{idTipoCosto}")
    @Transactional("secondTransactionManager")
    public String eliminar(@PathVariable Long idTipoCosto, RedirectAttributes redirectAttributes) {
        auditoriaSessionService.activarUsuarioActual();

        if (costoRepository.existsByTipoCosto_IdTipoCosto(idTipoCosto)
                || ingresoRepository.existsByTipoCosto_IdTipoCosto(idTipoCosto)) {
            redirectAttributes.addFlashAttribute("error",
                    "Este tipo de costo tiene costos o ingresos asociados, no se puede eliminar");
            return "redirect:/mantenimiento/tipos-costo";
        }

        try {
            tipoCostoRepository.deleteById(idTipoCosto);
        } catch (DataIntegrityViolationException e) {
            redirectAttributes.addFlashAttribute("error", "No se puede eliminar: tiene registros asociados");
            return "redirect:/mantenimiento/tipos-costo";
        }

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/tipos-costo";
    }

    private String obtenerUsuarioActual() {
        return SecurityUtils.getUsuarioActual() != null
                ? SecurityUtils.getUsuarioActual().getUsuario()
                : null;
    }
}
