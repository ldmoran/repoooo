package com.finanzas.gestionfinanzas.controller;

import com.finanzas.gestionfinanzas.entity.TipoDistribucion;
import com.finanzas.gestionfinanzas.repository.bdd.DistribucionPadreRepository;
import com.finanzas.gestionfinanzas.repository.bdd.TipoDistribucionRepository;
import com.finanzas.gestionfinanzas.service.impl.AuditoriaSessionService;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/mantenimiento/tipos-distribucion")
public class MantenimientoTipoDistribucionController {

    private final TipoDistribucionRepository tipoDistribucionRepository;
    private final DistribucionPadreRepository padreRepo;
    private final AuditoriaSessionService auditoriaSessionService;

    public MantenimientoTipoDistribucionController(TipoDistribucionRepository tipoDistribucionRepository,
                                                    DistribucionPadreRepository padreRepo,
                                                    AuditoriaSessionService auditoriaSessionService) {
        this.tipoDistribucionRepository = tipoDistribucionRepository;
        this.padreRepo = padreRepo;
        this.auditoriaSessionService = auditoriaSessionService;
    }

    @GetMapping
    public String listar(@RequestParam(defaultValue = "0") int page,
                         @RequestParam(required = false) String nombre,
                         @RequestParam(required = false) String estado,
                         HttpServletRequest request, Model model) {
        Page<TipoDistribucion> tiposDistribucionPage =
                tipoDistribucionRepository.buscar(normalizar(nombre), normalizar(estado), PageRequest.of(page, 10));

        model.addAttribute("path", request.getRequestURI());
        model.addAttribute("tiposDistribucionPage", tiposDistribucionPage);
        model.addAttribute("nombre", nombre);
        model.addAttribute("estado", estado);
        return "mantenimiento/tipos-distribucion";
    }

    private String normalizar(String valor) {
        if (valor == null) {
            return null;
        }
        String limpio = valor.trim();
        return limpio.isEmpty() ? null : limpio;
    }

    @PostMapping("/guardar")
    @Transactional("secondTransactionManager")
    public String guardar(@RequestParam(required = false) Long idTipoDistribucion,
                          @RequestParam String nombreTipoDistribucion,
                          @RequestParam String estado,
                          RedirectAttributes redirectAttributes) {

        auditoriaSessionService.activarUsuarioActual();

        TipoDistribucion tipoDistribucion = (idTipoDistribucion != null)
                ? tipoDistribucionRepository.findById(idTipoDistribucion).orElseThrow(() -> new RuntimeException("Tipo de distribución no encontrado"))
                : new TipoDistribucion();

        tipoDistribucion.setNombreTipoDistribucion(nombreTipoDistribucion.trim());
        tipoDistribucion.setEstado(estado);

        tipoDistribucionRepository.save(tipoDistribucion);

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/tipos-distribucion";
    }

    @PostMapping("/eliminar/{idTipoDistribucion}")
    @Transactional("secondTransactionManager")
    public String eliminar(@PathVariable Long idTipoDistribucion, RedirectAttributes redirectAttributes) {
        auditoriaSessionService.activarUsuarioActual();

        if (padreRepo.existsByTipoDistribucion_IdTipoDistribucion(idTipoDistribucion)) {
            redirectAttributes.addFlashAttribute("error",
                    "Este tipo de distribución tiene distribuciones asociadas, no se puede eliminar");
            return "redirect:/mantenimiento/tipos-distribucion";
        }

        try {
            tipoDistribucionRepository.deleteById(idTipoDistribucion);
        } catch (DataIntegrityViolationException e) {
            redirectAttributes.addFlashAttribute("error", "No se puede eliminar: tiene registros asociados");
            return "redirect:/mantenimiento/tipos-distribucion";
        }

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/tipos-distribucion";
    }
}
