package com.finanzas.gestionfinanzas.dto;

import java.time.LocalDateTime;

// Comprobantes que no están ligados a una factura puntual (ej. Comprobante de
// Costos de Mantenimiento > Costos, que aplica a TODOS los costos a la vez).
// Sin el contenido (BLOB), igual que ArchivoResumenDTO.
public class ComprobanteGlobalDTO {

    private final Long idArchivo;
    private final String nombreArchivo;
    private final String extension;
    private final String estado;
    private final LocalDateTime fechaCreacion;

    public ComprobanteGlobalDTO(Long idArchivo, String nombreArchivo, String extension, String estado,
                                LocalDateTime fechaCreacion) {
        this.idArchivo = idArchivo;
        this.nombreArchivo = nombreArchivo;
        this.extension = extension;
        this.estado = estado;
        this.fechaCreacion = fechaCreacion;
    }

    public Long getIdArchivo() {
        return idArchivo;
    }

    public String getNombreArchivo() {
        return nombreArchivo;
    }

    public String getExtension() {
        return extension;
    }

    public String getEstado() {
        return estado;
    }

    public LocalDateTime getFechaCreacion() {
        return fechaCreacion;
    }
}
