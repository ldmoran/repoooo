package com.finanzas.gestionfinanzas.dto;

import java.util.LinkedHashMap;
import java.util.Map;

// Una fila del reporte de Control de Ingresos: es una distribución concreta de una
// factura ya Aprobada, con su volumen y los costos que se le congelaron al aprobar.
// Los costos van en un mapa (nombre del costo -> total) porque las columnas se arman
// dinámicamente con los tipos de costo que realmente aparecen en el rango consultado.
public class ControlIngresoFilaDTO {

    private final String numFactura;
    private final String fecEmbarque;
    private final String fecDeposito;
    private final String compradora;
    private final String contrato;
    private final String buque;
    private final String producto;
    private final String distribucion;
    private final Double volumen;
    private final Double precio;
    private final Map<String, Double> costosPorNombre = new LinkedHashMap<>();

    public ControlIngresoFilaDTO(String numFactura, String fecEmbarque, String fecDeposito, String compradora,
                                 String contrato, String buque, String producto, String distribucion,
                                 Double volumen, Double precio) {
        this.numFactura = numFactura;
        this.fecEmbarque = fecEmbarque;
        this.fecDeposito = fecDeposito;
        this.compradora = compradora;
        this.contrato = contrato;
        this.buque = buque;
        this.producto = producto;
        this.distribucion = distribucion;
        this.volumen = volumen;
        this.precio = precio;
    }

    public void sumarCosto(String nombreCosto, Double total) {
        if (nombreCosto == null || total == null) {
            return;
        }
        costosPorNombre.merge(nombreCosto, total, Double::sum);
    }

    // Valor del embarque que corresponde a esta distribución: su volumen por el
    // precio por barril que trae la factura desde el ERP.
    public double getValorEmbarque() {
        if (volumen == null || precio == null) {
            return 0;
        }
        return volumen * precio;
    }

    public double getTotalCostos() {
        return costosPorNombre.values().stream().mapToDouble(Double::doubleValue).sum();
    }

    public double getCosto(String nombreCosto) {
        return costosPorNombre.getOrDefault(nombreCosto, 0.0);
    }

    public String getNumFactura() {
        return numFactura;
    }

    public String getFecEmbarque() {
        return fecEmbarque;
    }

    public String getFecDeposito() {
        return fecDeposito;
    }

    public String getCompradora() {
        return compradora;
    }

    public String getContrato() {
        return contrato;
    }

    public String getBuque() {
        return buque;
    }

    public String getProducto() {
        return producto;
    }

    public String getDistribucion() {
        return distribucion;
    }

    public Double getVolumen() {
        return volumen;
    }

    public Double getPrecio() {
        return precio;
    }

    public Map<String, Double> getCostosPorNombre() {
        return costosPorNombre;
    }
}
