package com.finanzas.gestionfinanzas.dto;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

// Resultado completo del reporte: las filas más las columnas de costo que aplican
// al rango consultado. Las columnas se arman según lo que realmente salió, para no
// mostrar columnas vacías ni quedarse corto si mañana agregan un costo nuevo.
public class ControlIngresoReporteDTO {

    private final List<ControlIngresoFilaDTO> filas;
    private final List<ColumnaCostoDTO> columnas;
    private final String desde;
    private final String hasta;

    public ControlIngresoReporteDTO(List<ControlIngresoFilaDTO> filas, List<ColumnaCostoDTO> columnas,
                                    String desde, String hasta) {
        this.filas = filas;
        this.columnas = columnas;
        this.desde = desde;
        this.hasta = hasta;
    }

    public List<ControlIngresoFilaDTO> getFilas() {
        return filas;
    }

    public List<ColumnaCostoDTO> getColumnas() {
        return columnas;
    }

    // Las mismas columnas agrupadas por entidad, para la cabecera de dos niveles
    // ("COSTOS PETROECUADOR" / "COSTOS MINISTERIO") igual que en el formato guía.
    public Map<String, List<ColumnaCostoDTO>> getColumnasPorEntidad() {
        Map<String, List<ColumnaCostoDTO>> porEntidad = new LinkedHashMap<>();
        for (ColumnaCostoDTO columna : columnas) {
            porEntidad.computeIfAbsent(columna.getEntidad(), k -> new java.util.ArrayList<>()).add(columna);
        }
        return porEntidad;
    }

    public String getDesde() {
        return desde;
    }

    public String getHasta() {
        return hasta;
    }

    public double getTotalVolumen() {
        return filas.stream().mapToDouble(f -> f.getVolumen() != null ? f.getVolumen() : 0).sum();
    }

    public double getTotalValorEmbarque() {
        return filas.stream().mapToDouble(ControlIngresoFilaDTO::getValorEmbarque).sum();
    }

    public double getTotalCostos() {
        return filas.stream().mapToDouble(ControlIngresoFilaDTO::getTotalCostos).sum();
    }

    public double getTotalCosto(String clave) {
        return filas.stream().mapToDouble(f -> f.getCosto(clave)).sum();
    }
}
