package com.finanzas.gestionfinanzas.dto;

import java.util.List;

public class CrudoCostosDTO {

    private final String nombreCrudo;
    private final List<TipoDistribucionCostosDTO> tipos;

    public CrudoCostosDTO(String nombreCrudo, List<TipoDistribucionCostosDTO> tipos) {
        this.nombreCrudo = nombreCrudo;
        this.tipos = tipos;
    }

    public String getNombreCrudo() {
        return nombreCrudo;
    }

    public List<TipoDistribucionCostosDTO> getTipos() {
        return tipos;
    }
}
