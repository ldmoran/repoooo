package com.finanzas.gestionfinanzas.dto;

import java.util.List;

public class CuentaIngresoDTO {

    private final String numeroCuenta;
    private final String descripcion;
    private final List<CostoLineaIngresoDTO> lineas;
    private final Double subtotal;

    public CuentaIngresoDTO(String numeroCuenta, String descripcion, List<CostoLineaIngresoDTO> lineas, Double subtotal) {
        this.numeroCuenta = numeroCuenta;
        this.descripcion = descripcion;
        this.lineas = lineas;
        this.subtotal = subtotal;
    }

    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public List<CostoLineaIngresoDTO> getLineas() {
        return lineas;
    }

    public Double getSubtotal() {
        return subtotal;
    }
}
