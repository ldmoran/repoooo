package com.finanzas.gestionfinanzas.dto;

public class DetalleFacturaResumenDTO {

    private final String crudo;
    private final String tipo;
    private final String distribucion;
    private final Double volumen;
    private final String costos;

    public DetalleFacturaResumenDTO(String crudo, String tipo, String distribucion, Double volumen, String costos) {
        this.crudo = crudo;
        this.tipo = tipo;
        this.distribucion = distribucion;
        this.volumen = volumen;
        this.costos = costos;
    }

    public String getCrudo() {
        return crudo;
    }

    public String getTipo() {
        return tipo;
    }

    public String getDistribucion() {
        return distribucion;
    }

    public Double getVolumen() {
        return volumen;
    }

    public String getCostos() {
        return costos;
    }
}
