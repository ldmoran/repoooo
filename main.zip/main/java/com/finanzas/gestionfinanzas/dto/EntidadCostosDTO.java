package com.finanzas.gestionfinanzas.dto;

import java.util.List;

public class EntidadCostosDTO {

    private final String nombreEntidad;
    private final List<CrudoCostosDTO> crudos;

    public EntidadCostosDTO(String nombreEntidad, List<CrudoCostosDTO> crudos) {
        this.nombreEntidad = nombreEntidad;
        this.crudos = crudos;
    }

    public String getNombreEntidad() {
        return nombreEntidad;
    }

    public List<CrudoCostosDTO> getCrudos() {
        return crudos;
    }
}
