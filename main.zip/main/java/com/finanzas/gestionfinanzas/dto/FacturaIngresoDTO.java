package com.finanzas.gestionfinanzas.dto;

import java.util.List;

public class FacturaIngresoDTO {

    private final Long idFactura;
    private final String numFactura;
    private final List<CuentaIngresoDTO> cuentas;
    private final Double total;

    public FacturaIngresoDTO(Long idFactura, String numFactura, List<CuentaIngresoDTO> cuentas, Double total) {
        this.idFactura = idFactura;
        this.numFactura = numFactura;
        this.cuentas = cuentas;
        this.total = total;
    }

    public Long getIdFactura() {
        return idFactura;
    }

    public String getNumFactura() {
        return numFactura;
    }

    public List<CuentaIngresoDTO> getCuentas() {
        return cuentas;
    }

    public Double getTotal() {
        return total;
    }
}
