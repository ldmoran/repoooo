package com.finanzas.gestionfinanzas.dto;

import java.util.Map;

public class NuevaDistribucionDTO {

    private final Long idHija;
    private final Double volumen;
    // Costos elegidos a mano (MEM/Ministerio) con el TOTAL que tecleó el usuario
    // para cada uno, porque en esos casos no se conoce el costo unitario.
    // Vacío/null cuando la distribución usa sus costos por defecto y el sistema
    // calcula el total como VALOR x VOLUMEN.
    private final Map<Long, Double> totalesManualPorTipoCosto;

    public NuevaDistribucionDTO(Long idHija, Double volumen, Map<Long, Double> totalesManualPorTipoCosto) {
        this.idHija = idHija;
        this.volumen = volumen;
        this.totalesManualPorTipoCosto = totalesManualPorTipoCosto;
    }

    public Long getIdHija() {
        return idHija;
    }

    public Double getVolumen() {
        return volumen;
    }

    public Map<Long, Double> getTotalesManualPorTipoCosto() {
        return totalesManualPorTipoCosto;
    }
}
