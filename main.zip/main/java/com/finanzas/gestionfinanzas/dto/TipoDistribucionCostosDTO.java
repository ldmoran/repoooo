package com.finanzas.gestionfinanzas.dto;

import java.util.List;

public class TipoDistribucionCostosDTO {

    private final String nombreTipo;
    private final List<String> columnasCosto;
    private final List<FilaCostoFacturaDTO> filas;

    public TipoDistribucionCostosDTO(String nombreTipo, List<String> columnasCosto, List<FilaCostoFacturaDTO> filas) {
        this.nombreTipo = nombreTipo;
        this.columnasCosto = columnasCosto;
        this.filas = filas;
    }

    public String getNombreTipo() {
        return nombreTipo;
    }

    public List<String> getColumnasCosto() {
        return columnasCosto;
    }

    public List<FilaCostoFacturaDTO> getFilas() {
        return filas;
    }
}
