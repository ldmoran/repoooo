package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CRUDO")
public class Crudo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_CRUDO")
    private Long idCrudo;

    @Column(name = "NOMBRE_CRUDO")
    private String nombreCrudo;

    @Column(name = "ESTADO")
    private String estado;

    public Long getIdCrudo() {
        return idCrudo;
    }

    public void setIdCrudo(Long idCrudo) {
        this.idCrudo = idCrudo;
    }

    public String getNombreCrudo() {
        return nombreCrudo;
    }

    public void setNombreCrudo(String nombreCrudo) {
        this.nombreCrudo = nombreCrudo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
