package com.finanzas.gestionfinanzas.entity;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "DETA_DISTRIBUCION")
public class DistribucionHija {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_DETA")
    private Long idDeta;

    @ManyToOne
    @JoinColumn(name = "ID_DISTRIBUCION")
    private DistribucionPadre distribucionPadre;

    @ManyToMany
    @JoinTable(name = "DETA_DISTRIBUCION_TIPO_COSTO",
            joinColumns = @JoinColumn(name = "ID_DETA"),
            inverseJoinColumns = @JoinColumn(name = "ID_TIPO_COSTO"))
    private List<TipoCosto> tiposCostoDefault;

    @Column(name = "CODIGO")
    private String codigo;

    @Column(name = "NOMBRE_COMPLETO")
    private String nombreCompleto;

    @Column(name = "ID_USUARIO_CREACION")
    private String idUsuarioCreacion;

    @Column(name = "FECHA_CREACION")
    private LocalDateTime fechaCreacion;

    // Getters y Setters
    public Long getIdDeta() {
        return idDeta;
    }

    public void setIdDeta(Long idDeta) {
        this.idDeta = idDeta;
    }

    public DistribucionPadre getDistribucionPadre() {
        return distribucionPadre;
    }

    public void setDistribucionPadre(DistribucionPadre distribucionPadre) {
        this.distribucionPadre = distribucionPadre;
    }

    public List<TipoCosto> getTiposCostoDefault() {
        return tiposCostoDefault;
    }

    public void setTiposCostoDefault(List<TipoCosto> tiposCostoDefault) {
        this.tiposCostoDefault = tiposCostoDefault;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public String getIdUsuarioCreacion() {
        return idUsuarioCreacion;
    }

    public void setIdUsuarioCreacion(String idUsuarioCreacion) {
        this.idUsuarioCreacion = idUsuarioCreacion;
    }

    public LocalDateTime getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(LocalDateTime fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }
}
