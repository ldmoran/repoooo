package com.finanzas.gestionfinanzas.entity;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "DISTRIBUCION")
public class DistribucionPadre {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_DISTRIBUCION")
	private Long idDistribucion;

    @ManyToOne
    @JoinColumn(name = "ID_CRUDO")
    private Crudo crudo;

    @ManyToOne
    @JoinColumn(name = "ID_TIPO_DISTRIBUCION")
    private TipoDistribucion tipoDistribucion;

    @Column(name = "ID_USUARIO_CREACION")
    private String idUsuarioCreacion;

    @Column(name = "FECHA_CREACION")
    private LocalDateTime fechaCreacion;

    // Getters y Setters
    public Long getIdDistribucion() {
        return idDistribucion;
    }

    public void setIdDistribucion(Long idDistribucion) {
        this.idDistribucion = idDistribucion;
    }

    public Crudo getCrudo() {
        return crudo;
    }

    public void setCrudo(Crudo crudo) {
        this.crudo = crudo;
    }

    public TipoDistribucion getTipoDistribucion() {
        return tipoDistribucion;
    }

    public void setTipoDistribucion(TipoDistribucion tipoDistribucion) {
        this.tipoDistribucion = tipoDistribucion;
    }

    public String getIdUsuarioCreacion() {
        return idUsuarioCreacion;
    }

    public void setIdUsuarioCreacion(String idUsuarioCreacion) {
        this.idUsuarioCreacion = idUsuarioCreacion;
    }

    public LocalDateTime getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(LocalDateTime fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }
}
