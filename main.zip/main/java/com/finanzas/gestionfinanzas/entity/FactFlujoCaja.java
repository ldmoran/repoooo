package com.finanzas.gestionfinanzas.entity;

import org.springframework.data.domain.Persistable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

// Tabla del lado EBS (mismo esquema/datasource que APPS.XXOCS_AR_FACTURAS_INGRESOS_V),
// ya existente y fuera de nuestro control de DDL. No tiene autonumerado configurado en
// BD, así que el ID lo calcula FactFlujoCajaService (MAX(ID)+1) antes de guardarse.
// Implementa Persistable para forzar siempre INSERT (nunca merge/select) al guardar,
// ya que llega con un ID asignado manualmente y esta app nunca la vuelve a leer.
@Entity
@Table(name = "XXOCS_AR_FACT_FLUJO_CAJA", schema = "APPS")
public class FactFlujoCaja implements Persistable<Long> {

    @Id
    @Column(name = "ID")
    private Long id;

    @Column(name = "CUSTOMER_TRX_ID")
    private Long customerTrxId;

    @Column(name = "CUENTA_BANCO")
    private String cuentaBanco;

    @Column(name = "MONTO")
    private Double monto;

    @Column(name = "FECHA_CARGA")
    private LocalDateTime fechaCarga;

    @Override
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public boolean isNew() {
        return true;
    }

    public Long getCustomerTrxId() {
        return customerTrxId;
    }

    public void setCustomerTrxId(Long customerTrxId) {
        this.customerTrxId = customerTrxId;
    }

    public String getCuentaBanco() {
        return cuentaBanco;
    }

    public void setCuentaBanco(String cuentaBanco) {
        this.cuentaBanco = cuentaBanco;
    }

    public Double getMonto() {
        return monto;
    }

    public void setMonto(Double monto) {
        this.monto = monto;
    }

    public LocalDateTime getFechaCarga() {
        return fechaCarga;
    }

    public void setFechaCarga(LocalDateTime fechaCarga) {
        this.fechaCarga = fechaCarga;
    }
}
