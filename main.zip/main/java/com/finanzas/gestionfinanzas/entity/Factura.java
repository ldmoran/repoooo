package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.time.LocalDate;

@Entity
public class Factura {

    @Id
    @Column(name = "CUSTOMER_TRX_ID")
    private Long customerTrxId;

    @Column(name = "NUM_FACTURA")
    private String numFactura;

    @Column(name = "FEC_EMBARQUE")
    private String fecEmbarque;

    @Column(name = "FEC_DEPOSITO")
    private String fecDeposito;

    @Column(name = "RUC")
    private String ruc;

    @Column(name = "COMPANIA")
    private String compania;

    @Column(name = "CONTRATO")
    private String contrato;

    @Column(name = "BUQUE")
    private String buque;

    @Column(name = "CANTIDAD")
    // Barriles del embarque. Viene con decimales desde el ERP (ej. 357051,76):
    // mapearlo como entero recortaba la parte decimal.
    private Double cantidad;

    @Column(name = "PRECIO")
    private Double precio;

    @Column(name = "SUBTOTAL")
    private Double subtotal;

    @Column(name = "DESCRIPCION")
    private String descripcion;

    @Column(name = "FEC_FACTURA")
    private String fecFactura;

    
    // Getters y setters
    public Long getCustomerTrxId() { return customerTrxId; }
    public void setCustomerTrxId(Long customerTrxId) { this.customerTrxId = customerTrxId; }

    public String getNumFactura() { return numFactura; }
    public void setNumFactura(String numFactura) { this.numFactura = numFactura; }

    public String getFecEmbarque() { return fecEmbarque; }
    public void setFecEmbarque(String fecEmbarque) { this.fecEmbarque = fecEmbarque; }

    public String getFecDeposito() { return fecDeposito; }
    public void setFecDeposito(String fecDeposito) { this.fecDeposito = fecDeposito; }

    public String getRuc() { return ruc; }
    public void setRuc(String ruc) { this.ruc = ruc; }

    public String getCompania() { return compania; }
    public void setCompania(String compania) { this.compania = compania; }

    public String getContrato() { return contrato; }
    public void setContrato(String contrato) { this.contrato = contrato; }

    public String getBuque() { return buque; }
    public void setBuque(String buque) { this.buque = buque; }

    public Double getCantidad() { return cantidad; }
    public void setCantidad(Double cantidad) { this.cantidad = cantidad; }

    public Double getPrecio() { return precio; }
    public void setPrecio(Double precio) { this.precio = precio; }

    public Double getSubtotal() { return subtotal; }
    public void setSubtotal(Double subtotal) { this.subtotal = subtotal; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public String getFecFactura() { return fecFactura; }
    public void setFecFactura(String fecFactura) { this.fecFactura = fecFactura; }

}
