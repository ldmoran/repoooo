package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Table(name = "TIPO_ARCHIVO")
public class TipoArchivo {

    // Nombres del catálogo con los que trabaja el código (ver seeds en reset_bd.sql).
    public static final String COMPROBANTE_DISTRIBUCION = "Comprobante de Distribución";
    public static final String COMPROBANTE_COSTOS = "Comprobante de Costos";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_TIPO_ARCHIVO")
    private Long idTipoArchivo;

    @Column(name = "NOMBRE_TIPO_ARCHIVO")
    private String nombreTipoArchivo;

    @Column(name = "ESTADO")
    private String estado;

    @Column(name = "ID_USUARIO_CREACION")
    private String idUsuarioCreacion;

    @Column(name = "FECHA_CREACION")
    private LocalDateTime fechaCreacion;

    public Long getIdTipoArchivo() {
        return idTipoArchivo;
    }

    public void setIdTipoArchivo(Long idTipoArchivo) {
        this.idTipoArchivo = idTipoArchivo;
    }

    public String getNombreTipoArchivo() {
        return nombreTipoArchivo;
    }

    public void setNombreTipoArchivo(String nombreTipoArchivo) {
        this.nombreTipoArchivo = nombreTipoArchivo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getIdUsuarioCreacion() {
        return idUsuarioCreacion;
    }

    public void setIdUsuarioCreacion(String idUsuarioCreacion) {
        this.idUsuarioCreacion = idUsuarioCreacion;
    }

    public LocalDateTime getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(LocalDateTime fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }
}
