package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TIPO_DISTRIBUCION")
public class TipoDistribucion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_TIPO_DISTRIBUCION")
    private Long idTipoDistribucion;

    @Column(name = "NOMBRE_TIPO_DISTRIBUCION")
    private String nombreTipoDistribucion;

    @Column(name = "ESTADO")
    private String estado;

    public Long getIdTipoDistribucion() {
        return idTipoDistribucion;
    }

    public void setIdTipoDistribucion(Long idTipoDistribucion) {
        this.idTipoDistribucion = idTipoDistribucion;
    }

    public String getNombreTipoDistribucion() {
        return nombreTipoDistribucion;
    }

    public void setNombreTipoDistribucion(String nombreTipoDistribucion) {
        this.nombreTipoDistribucion = nombreTipoDistribucion;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
