package com.finanzas.gestionfinanzas.repository.apps;

import com.finanzas.gestionfinanzas.entity.FactFlujoCaja;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface FactFlujoCajaRepository extends JpaRepository<FactFlujoCaja, Long> {

    @Query("SELECT COALESCE(MAX(f.id), 0) FROM FactFlujoCaja f")
    Long obtenerMaxId();
}
