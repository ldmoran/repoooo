package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.dto.ArchivoResumenDTO;
import com.finanzas.gestionfinanzas.dto.ComprobanteGlobalDTO;
import com.finanzas.gestionfinanzas.entity.Archivo;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ArchivoRepository extends JpaRepository<Archivo, Long> {

    @Query("SELECT new com.finanzas.gestionfinanzas.dto.ArchivoResumenDTO(" +
            "a.idArchivo, a.factura.idFactura, a.tipoArchivo.idTipoArchivo, a.tipoArchivo.nombreTipoArchivo, a.nombreArchivo, a.extension, a.fechaCreacion) " +
            "FROM Archivo a WHERE a.factura.idFactura = :idFactura AND a.estado = 'A' ORDER BY a.idArchivo DESC")
    List<ArchivoResumenDTO> findActivosResumenByFactura(@Param("idFactura") Long idFactura);

    @Query("SELECT new com.finanzas.gestionfinanzas.dto.ArchivoResumenDTO(" +
            "a.idArchivo, a.factura.idFactura, a.tipoArchivo.idTipoArchivo, a.tipoArchivo.nombreTipoArchivo, a.nombreArchivo, a.extension, a.fechaCreacion) " +
            "FROM Archivo a WHERE a.factura.idFactura IN :idsFactura AND a.estado = 'A' ORDER BY a.idArchivo DESC")
    List<ArchivoResumenDTO> findActivosResumenByFacturaIn(@Param("idsFactura") List<Long> idsFactura);

    // Comprobantes GLOBALES (sin factura, ej. Comprobante de Costos): no navega
    // a.factura.idFactura porque para estas filas la factura es null (y esa
    // navegación haría un inner join que las excluiría).
    @Query("SELECT new com.finanzas.gestionfinanzas.dto.ComprobanteGlobalDTO(" +
            "a.idArchivo, a.nombreArchivo, a.extension, a.estado, a.fechaCreacion) " +
            "FROM Archivo a WHERE a.factura IS NULL AND a.tipoArchivo.idTipoArchivo = :idTipoArchivo ORDER BY a.idArchivo DESC")
    List<ComprobanteGlobalDTO> findResumenGlobalByTipoArchivo(@Param("idTipoArchivo") Long idTipoArchivo, Pageable pageable);

    Optional<Archivo> findByFactura_IdFacturaAndTipoArchivo_IdTipoArchivoAndEstado(Long idFactura, Long idTipoArchivo, String estado);

    Optional<Archivo> findByFacturaIsNullAndTipoArchivo_IdTipoArchivoAndEstado(Long idTipoArchivo, String estado);

    boolean existsByTipoArchivo_IdTipoArchivo(Long idTipoArchivo);
}
