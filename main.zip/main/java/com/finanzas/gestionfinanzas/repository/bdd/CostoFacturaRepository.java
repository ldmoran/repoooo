package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.CostoFactura;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CostoFacturaRepository extends JpaRepository<CostoFactura, Long> {

    @Modifying
    @Query("DELETE FROM CostoFactura cf WHERE cf.factura.idFactura = :idFactura")
    void deleteByFactura_IdFactura(@Param("idFactura") Long idFactura);

    @Query("SELECT cf FROM CostoFactura cf " +
            "LEFT JOIN FETCH cf.tipoCosto tc " +
            "LEFT JOIN FETCH tc.cuenta " +
            "LEFT JOIN FETCH cf.factura f " +
            "WHERE f.idFactura IN :idsFactura")
    List<CostoFactura> findConCuentaByFacturaIn(@Param("idsFactura") List<Long> idsFactura);

    // Todo lo necesario para el reporte de Control de Ingresos: el costo congelado
    // con su factura, su distribución y el producto al que pertenece.
    @Query("SELECT cf FROM CostoFactura cf " +
            "JOIN FETCH cf.factura f " +
            "JOIN FETCH cf.tipoCosto tc " +
            "LEFT JOIN FETCH tc.cuenta " +
            "LEFT JOIN FETCH tc.crudoEntidad " +
            "JOIN FETCH cf.detalleDistribucion dd " +
            "JOIN FETCH dd.distribucionHija dh " +
            "JOIN FETCH dh.distribucionPadre dp " +
            "LEFT JOIN FETCH dp.crudo " +
            "ORDER BY f.numFactura, dh.nombreCompleto")
    List<CostoFactura> findTodoParaControlIngresos();
}
