package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.Crudo;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CrudoRepository extends JpaRepository<Crudo, Long> {
    List<Crudo> findAllByOrderByNombreCrudoAsc();

    List<Crudo> findByEstadoOrderByNombreCrudoAsc(String estado);

    @Query("SELECT c FROM Crudo c " +
            "WHERE (:nombre IS NULL OR UPPER(c.nombreCrudo) LIKE UPPER(CONCAT('%', :nombre, '%'))) " +
            "AND (:estado IS NULL OR c.estado = :estado) " +
            "ORDER BY c.nombreCrudo")
    Page<Crudo> buscar(@Param("nombre") String nombre, @Param("estado") String estado, Pageable pageable);
}
