package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.Cuenta;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CuentaRepository extends JpaRepository<Cuenta, Long> {
    List<Cuenta> findByEstadoOrderByNumeroCuentaAsc(String estado);

    @Query("SELECT c FROM Cuenta c " +
            "WHERE (:numero IS NULL OR UPPER(c.numeroCuenta) LIKE UPPER(CONCAT('%', :numero, '%'))) " +
            "AND (:estado IS NULL OR c.estado = :estado) " +
            "ORDER BY c.numeroCuenta")
    Page<Cuenta> buscar(@Param("numero") String numero, @Param("estado") String estado, Pageable pageable);
}
