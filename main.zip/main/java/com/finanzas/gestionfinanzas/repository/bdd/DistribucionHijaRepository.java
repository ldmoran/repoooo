package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.DistribucionHija;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DistribucionHijaRepository extends JpaRepository<DistribucionHija, Long> {

    @Query("SELECT dh FROM DistribucionHija dh " +
            "LEFT JOIN FETCH dh.distribucionPadre dp " +
            "LEFT JOIN FETCH dp.crudo " +
            "LEFT JOIN FETCH dh.tiposCostoDefault " +
            "WHERE dh.idDeta = :idDeta")
    Optional<DistribucionHija> findByIdConCostosDefault(@Param("idDeta") Long idDeta);

    @Query("SELECT DISTINCT dh FROM DistribucionHija dh " +
            "LEFT JOIN FETCH dh.distribucionPadre dp " +
            "LEFT JOIN FETCH dp.crudo " +
            "LEFT JOIN FETCH dp.tipoDistribucion " +
            "LEFT JOIN FETCH dh.tiposCostoDefault " +
            "ORDER BY dp.crudo.nombreCrudo, dp.tipoDistribucion.nombreTipoDistribucion, dh.nombreCompleto")
    List<DistribucionHija> findAllConDetalle();

    @Query(value = "SELECT dh FROM DistribucionHija dh " +
            "LEFT JOIN FETCH dh.distribucionPadre dp " +
            "LEFT JOIN FETCH dp.crudo c " +
            "LEFT JOIN FETCH dp.tipoDistribucion t " +
            "WHERE (:idCrudo IS NULL OR c.idCrudo = :idCrudo) " +
            "AND (:idTipoDistribucion IS NULL OR t.idTipoDistribucion = :idTipoDistribucion) " +
            "AND (:texto IS NULL OR UPPER(dh.nombreCompleto) LIKE UPPER(CONCAT('%', :texto, '%')) " +
            "     OR UPPER(dh.codigo) LIKE UPPER(CONCAT('%', :texto, '%'))) " +
            "ORDER BY c.nombreCrudo, t.nombreTipoDistribucion, dh.nombreCompleto",
            countQuery = "SELECT COUNT(dh) FROM DistribucionHija dh " +
            "LEFT JOIN dh.distribucionPadre dp " +
            "LEFT JOIN dp.crudo c " +
            "LEFT JOIN dp.tipoDistribucion t " +
            "WHERE (:idCrudo IS NULL OR c.idCrudo = :idCrudo) " +
            "AND (:idTipoDistribucion IS NULL OR t.idTipoDistribucion = :idTipoDistribucion) " +
            "AND (:texto IS NULL OR UPPER(dh.nombreCompleto) LIKE UPPER(CONCAT('%', :texto, '%')) " +
            "     OR UPPER(dh.codigo) LIKE UPPER(CONCAT('%', :texto, '%')))")
    Page<DistribucionHija> buscar(@Param("idCrudo") Long idCrudo,
                                  @Param("idTipoDistribucion") Long idTipoDistribucion,
                                  @Param("texto") String texto,
                                  Pageable pageable);

    boolean existsByCodigo(String codigo);

    boolean existsByCodigoAndIdDetaNot(String codigo, Long idDeta);

    List<DistribucionHija> findByCodigoIsNull();
}
