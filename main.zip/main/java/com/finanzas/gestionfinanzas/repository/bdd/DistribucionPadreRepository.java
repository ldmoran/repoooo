// src/main/java/com/finanzas/gestionfinanzas/repository/bdd/DistribucionPadreRepository.java
package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.DistribucionPadre;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DistribucionPadreRepository extends JpaRepository<DistribucionPadre, Long> {
    Optional<DistribucionPadre> findByCrudo_IdCrudoAndTipoDistribucion_IdTipoDistribucion(Long idCrudo, Long idTipoDistribucion);

    boolean existsByCrudo_IdCrudo(Long idCrudo);

    boolean existsByTipoDistribucion_IdTipoDistribucion(Long idTipoDistribucion);

    @Query("SELECT dp FROM DistribucionPadre dp LEFT JOIN FETCH dp.crudo LEFT JOIN FETCH dp.tipoDistribucion")
    List<DistribucionPadre> findAllConCatalogos();
}
