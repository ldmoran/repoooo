package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.EnvioEbsCuenta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EnvioEbsCuentaRepository extends JpaRepository<EnvioEbsCuenta, Long> {

    @Query("SELECT ec FROM EnvioEbsCuenta ec LEFT JOIN FETCH ec.cuenta WHERE ec.envioEbs.idEnvioEbs = :idEnvioEbs")
    List<EnvioEbsCuenta> findByEnvioEbs_IdEnvioEbs(@Param("idEnvioEbs") Long idEnvioEbs);
}
