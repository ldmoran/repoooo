package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.FacturaCuenta;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface FacturaCuentaRepository extends JpaRepository<FacturaCuenta, Long> {

    @Modifying
    @Query("DELETE FROM FacturaCuenta fc WHERE fc.factura.idFactura = :idFactura")
    void deleteByFactura_IdFactura(@Param("idFactura") Long idFactura);

    @Query("SELECT fc FROM FacturaCuenta fc " +
            "LEFT JOIN FETCH fc.cuenta " +
            "LEFT JOIN FETCH fc.factura f " +
            "WHERE f.idFactura IN :idsFactura " +
            "ORDER BY f.idFactura DESC")
    List<FacturaCuenta> findConCuentaByFacturaIn(@Param("idsFactura") List<Long> idsFactura);

    @Query(value = "SELECT fc FROM FacturaCuenta fc LEFT JOIN FETCH fc.cuenta LEFT JOIN FETCH fc.factura ORDER BY fc.idFacturaCuenta DESC",
            countQuery = "SELECT COUNT(fc) FROM FacturaCuenta fc")
    Page<FacturaCuenta> findAllConDetalle(Pageable pageable);
}
