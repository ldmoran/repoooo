package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.FacturasBDD;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Repository
@Transactional("secondTransactionManager") // usa el datasource SFINGRESO
public interface FacturasBDDRepository extends JpaRepository<FacturasBDD, Long> {
    boolean existsByCustomerTrxId(Long customerTrxId);

    boolean existsByCustomerTrxIdAndSecuencia(Long customerTrxId, Integer secuencia);

    boolean existsByNumFacturaAndRuc(String numFactura, String ruc);

    Optional<FacturasBDD> findByCustomerTrxId(Long customerTrxId);

    List<FacturasBDD> findByCustomerTrxIdIn(Collection<Long> customerTrxIds);

    @Query("SELECT f FROM FacturasBDD f WHERE " +
            "(:ruc IS NULL OR f.ruc = :ruc) " +
            "AND (:numFactura IS NULL OR f.numFactura = :numFactura) " +
            "AND (:fecEmbarque IS NULL OR f.fecEmbarque = :fecEmbarque) " +
            "AND (:fecDeposito IS NULL OR f.fecDeposito = :fecDeposito) " +
            "AND (:fecFactura IS NULL OR f.fecFactura = :fecFactura) " +
            "AND (:estado IS NULL OR UPPER(f.estado) = UPPER(:estado)) " +
            // Una factura ya incluida en un envío a EBS guardado no debe volver a
            // aparecer aquí (evita seleccionarla/enviarla dos veces).
            "AND NOT EXISTS (SELECT 1 FROM EnvioEbsFactura ef WHERE ef.factura = f) " +
            // Lo último trabajado primero: al guardar distribuciones o aprobar una
            // factura, ésta sube al tope del listado. El id sirve de desempate.
            "ORDER BY f.fechaModificacion DESC NULLS LAST, f.idFactura DESC")
    Page<FacturasBDD> buscar(@Param("ruc") String ruc,
                             @Param("numFactura") String numFactura,
                             @Param("fecEmbarque") String fecEmbarque,
                             @Param("fecDeposito") String fecDeposito,
                             @Param("fecFactura") String fecFactura,
                             @Param("estado") String estado,
                             Pageable pageable);
}
