package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.Ingreso;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface IngresoRepository extends JpaRepository<Ingreso, Long> {

    @Query("SELECT i FROM Ingreso i " +
            "LEFT JOIN FETCH i.detalleDistribucion dd " +
            "LEFT JOIN FETCH dd.distribucionHija dh " +
            "LEFT JOIN FETCH dh.distribucionPadre dp " +
            "LEFT JOIN FETCH dp.crudo " +
            "LEFT JOIN FETCH dp.tipoDistribucion " +
            "LEFT JOIN FETCH dd.factura " +
            "LEFT JOIN FETCH i.tipoCosto tc " +
            "LEFT JOIN FETCH tc.crudo " +
            "LEFT JOIN FETCH tc.crudoEntidad " +
            "WHERE dd.factura.idFactura = :idFactura " +
            "ORDER BY i.idIngreso DESC")
    List<Ingreso> findByDetalleDistribucion_Factura_IdFactura(Long idFactura);

    @Query("SELECT i FROM Ingreso i " +
            "LEFT JOIN FETCH i.tipoCosto tc " +
            "LEFT JOIN FETCH tc.crudo " +
            "LEFT JOIN FETCH tc.crudoEntidad " +
            "WHERE i.detalleDistribucion.idDetalle IN :idsDetalle")
    List<Ingreso> findByDetalleDistribucion_IdDetalleIn(@Param("idsDetalle") List<Long> idsDetalle);

    boolean existsByTipoCosto_IdTipoCosto(Long idTipoCosto);

    @Modifying
    @Query("DELETE FROM Ingreso i WHERE i.detalleDistribucion.idDetalle = :idDetalle")
    void deleteByDetalleDistribucion_IdDetalle(@Param("idDetalle") Long idDetalle);
}
