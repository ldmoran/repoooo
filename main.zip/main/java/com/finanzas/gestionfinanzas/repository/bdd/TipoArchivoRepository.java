package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.TipoArchivo;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface TipoArchivoRepository extends JpaRepository<TipoArchivo, Long> {
    List<TipoArchivo> findByEstadoOrderByNombreTipoArchivoAsc(String estado);

    Optional<TipoArchivo> findByNombreTipoArchivo(String nombreTipoArchivo);

    // Los adjuntos de una factura son siempre del mismo tipo, así que el combo de
    // las pantallas de Facturas / Ver distribuciones solo ofrece ese.
    List<TipoArchivo> findByNombreTipoArchivoAndEstado(String nombreTipoArchivo, String estado);

    @Query("SELECT t FROM TipoArchivo t " +
            "WHERE (:nombre IS NULL OR UPPER(t.nombreTipoArchivo) LIKE UPPER(CONCAT('%', :nombre, '%'))) " +
            "AND (:estado IS NULL OR t.estado = :estado) " +
            "ORDER BY t.nombreTipoArchivo")
    Page<TipoArchivo> buscar(@Param("nombre") String nombre, @Param("estado") String estado, Pageable pageable);
}
