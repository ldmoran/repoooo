package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.TipoCosto;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface TipoCostoRepository extends JpaRepository<TipoCosto, Long> {

    @Query("SELECT tc FROM TipoCosto tc LEFT JOIN FETCH tc.crudo LEFT JOIN FETCH tc.crudoEntidad LEFT JOIN FETCH tc.cuenta ORDER BY tc.crudo.nombreCrudo, tc.nombreCosto")
    List<TipoCosto> findAllConCrudo();

    List<TipoCosto> findByCrudo_IdCrudo(Long idCrudo);

    boolean existsByCrudo_IdCrudo(Long idCrudo);

    boolean existsByCrudoEntidad_IdGrupo(Long idGrupo);

    boolean existsByCuenta_IdCuenta(Long idCuenta);

    @Query(value = "SELECT tc FROM TipoCosto tc " +
            "LEFT JOIN FETCH tc.crudo c " +
            "LEFT JOIN FETCH tc.crudoEntidad ce " +
            "LEFT JOIN FETCH tc.cuenta cu " +
            "WHERE (:idCrudo IS NULL OR c.idCrudo = :idCrudo) " +
            "AND (:idGrupo IS NULL OR ce.idGrupo = :idGrupo) " +
            "AND (:nombreCosto IS NULL OR UPPER(tc.nombreCosto) LIKE UPPER(CONCAT('%', :nombreCosto, '%'))) " +
            "ORDER BY c.nombreCrudo, tc.nombreCosto",
            countQuery = "SELECT COUNT(tc) FROM TipoCosto tc " +
            "LEFT JOIN tc.crudo c " +
            "LEFT JOIN tc.crudoEntidad ce " +
            "WHERE (:idCrudo IS NULL OR c.idCrudo = :idCrudo) " +
            "AND (:idGrupo IS NULL OR ce.idGrupo = :idGrupo) " +
            "AND (:nombreCosto IS NULL OR UPPER(tc.nombreCosto) LIKE UPPER(CONCAT('%', :nombreCosto, '%')))")
    Page<TipoCosto> buscar(@Param("idCrudo") Long idCrudo,
                           @Param("idGrupo") Long idGrupo,
                           @Param("nombreCosto") String nombreCosto,
                           Pageable pageable);
}
