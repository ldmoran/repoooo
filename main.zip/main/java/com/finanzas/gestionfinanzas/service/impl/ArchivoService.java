package com.finanzas.gestionfinanzas.service.impl;

import com.finanzas.gestionfinanzas.entity.Archivo;
import com.finanzas.gestionfinanzas.entity.FacturasBDD;
import com.finanzas.gestionfinanzas.entity.TipoArchivo;
import com.finanzas.gestionfinanzas.repository.bdd.ArchivoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.CostoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.FacturasBDDRepository;
import com.finanzas.gestionfinanzas.repository.bdd.TipoArchivoRepository;
import com.finanzas.gestionfinanzas.utils.SecurityUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;

@Service
public class ArchivoService {

    private final ArchivoRepository archivoRepository;
    private final FacturasBDDRepository facturasBDDRepository;
    private final TipoArchivoRepository tipoArchivoRepository;
    private final CostoRepository costoRepository;
    private final AuditoriaSessionService auditoriaSessionService;

    public ArchivoService(ArchivoRepository archivoRepository,
                          FacturasBDDRepository facturasBDDRepository,
                          TipoArchivoRepository tipoArchivoRepository,
                          CostoRepository costoRepository,
                          AuditoriaSessionService auditoriaSessionService) {
        this.archivoRepository = archivoRepository;
        this.facturasBDDRepository = facturasBDDRepository;
        this.tipoArchivoRepository = tipoArchivoRepository;
        this.costoRepository = costoRepository;
        this.auditoriaSessionService = auditoriaSessionService;
    }

    @Transactional("secondTransactionManager")
    public void subirArchivo(Long idFactura, Long idTipoArchivo, MultipartFile file) {
        auditoriaSessionService.activarUsuarioActual();
        String extension = detectarExtension(file);

        FacturasBDD factura = facturasBDDRepository.findById(idFactura)
                .orElseThrow(() -> new RuntimeException("Factura no encontrada"));

        if ("A".equalsIgnoreCase(factura.getEstado())) {
            throw new RuntimeException("La factura ya está Aprobada: no se pueden subir ni reemplazar archivos");
        }

        TipoArchivo tipoArchivo = tipoArchivoRepository.findById(idTipoArchivo)
                .orElseThrow(() -> new RuntimeException("Tipo de archivo no encontrado"));

        // El archivo activo anterior del mismo tipo pasa a inactivo (se conserva como historial, no se borra).
        archivoRepository.findByFactura_IdFacturaAndTipoArchivo_IdTipoArchivoAndEstado(idFactura, idTipoArchivo, "A")
                .ifPresent(anterior -> {
                    anterior.setEstado("I");
                    archivoRepository.save(anterior);
                });

        Archivo archivo = new Archivo();
        archivo.setFactura(factura);
        archivo.setTipoArchivo(tipoArchivo);
        guardarContenido(archivo, file, extension);

        archivoRepository.save(archivo);
    }

    private String detectarExtension(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new RuntimeException("Debe seleccionarse un archivo (PDF, Word o Excel)");
        }

        String nombre = file.getOriginalFilename() != null ? file.getOriginalFilename().toLowerCase() : "";
        String contentType = file.getContentType() != null ? file.getContentType().toLowerCase() : "";

        if (contentType.equals("application/pdf") || nombre.endsWith(".pdf")) {
            return "PDF";
        }
        if (contentType.equals("application/msword")
                || contentType.equals("application/vnd.openxmlformats-officedocument.wordprocessingml.document")
                || nombre.endsWith(".doc") || nombre.endsWith(".docx")) {
            return "WORD";
        }
        if (contentType.equals("application/vnd.ms-excel")
                || contentType.equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                || nombre.endsWith(".xls") || nombre.endsWith(".xlsx")) {
            return "EXCEL";
        }

        throw new RuntimeException("Solo se permiten archivos PDF, Word o Excel");
    }

    private void guardarContenido(Archivo archivo, MultipartFile file, String extension) {
        String usuarioActual = SecurityUtils.getUsuarioActual() != null
                ? SecurityUtils.getUsuarioActual().getUsuario()
                : null;

        archivo.setNombreArchivo(file.getOriginalFilename());
        archivo.setExtension(extension);
        try {
            archivo.setContenido(file.getBytes());
        } catch (IOException e) {
            throw new RuntimeException("No se pudo leer el archivo subido");
        }
        archivo.setEstado("A");
        archivo.setIdUsuarioCreacion(usuarioActual);
        archivo.setFechaCreacion(LocalDateTime.now());
    }

    // Comprobante GLOBAL (sin ligar a una factura) que respalda cualquier
    // creación/edición de costos en Mantenimiento > Costos. Reactiva TODOS los
    // costos que hayan quedado INACTIVOS al guardarse (no es un archivo por
    // costo: uno solo cubre todos los cambios pendientes).
    @Transactional("secondTransactionManager")
    public void subirComprobanteCostos(MultipartFile file) {
        auditoriaSessionService.activarUsuarioActual();
        String extension = detectarExtension(file);

        TipoArchivo tipoArchivo = tipoArchivoRepository.findByNombreTipoArchivo(TipoArchivo.COMPROBANTE_COSTOS)
                .orElseThrow(() -> new RuntimeException(
                        "No existe el Tipo de Archivo 'Comprobante de Costos' en Mantenimiento > Tipos de archivo"));

        archivoRepository.findByFacturaIsNullAndTipoArchivo_IdTipoArchivoAndEstado(tipoArchivo.getIdTipoArchivo(), "A")
                .ifPresent(anterior -> {
                    anterior.setEstado("I");
                    archivoRepository.save(anterior);
                });

        Archivo archivo = new Archivo();
        archivo.setFactura(null);
        archivo.setTipoArchivo(tipoArchivo);
        guardarContenido(archivo, file, extension);

        archivoRepository.save(archivo);

        costoRepository.activarTodos();
    }

    @Transactional("secondTransactionManager")
    public void eliminarArchivo(Long idArchivo) {
        auditoriaSessionService.activarUsuarioActual();
        Archivo archivo = archivoRepository.findById(idArchivo)
                .orElseThrow(() -> new RuntimeException("Archivo no encontrado"));

        FacturasBDD factura = archivo.getFactura();
        if (factura != null && "A".equalsIgnoreCase(factura.getEstado())) {
            throw new RuntimeException("La factura ya está Aprobada: no se pueden eliminar sus archivos");
        }

        archivo.setEstado("I");
        archivoRepository.save(archivo);
    }
}
