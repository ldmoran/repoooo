package com.finanzas.gestionfinanzas.service.impl;

import com.finanzas.gestionfinanzas.dto.ColumnaCostoDTO;
import com.finanzas.gestionfinanzas.dto.ControlIngresoFilaDTO;
import com.finanzas.gestionfinanzas.dto.ControlIngresoReporteDTO;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.PrintSetup;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

// Genera el .xlsx del reporte de Control de Ingresos con el mismo contenido que
// el PDF: cabecera, una fila por distribución y una fila de totales al final.
@Service
public class ControlIngresoExcelService {

    private static final byte[] AZUL_OSCURO = {0, 47, 82};
    private static final byte[] AZUL_MEDIO = {0, 115, (byte) 171};
    private static final byte[] GRIS_FILA = {(byte) 244, (byte) 247, (byte) 249};
    private static final byte[] GRIS_BORDE = {(byte) 208, (byte) 216, (byte) 222};

    private static final int COLUMNAS_FIJAS = 12;
    private static final int ANCHO_MINIMO = 10 * 256;
    private static final int ANCHO_MAXIMO = 38 * 256;

    public void escribir(ControlIngresoReporteDTO reporte, OutputStream salida) throws IOException {
        try (XSSFWorkbook libro = new XSSFWorkbook()) {
            XSSFSheet hoja = libro.createSheet("Control de Ingresos");

            XSSFCellStyle estiloTitulo = crearEstiloTitulo(libro);
            XSSFCellStyle estiloSubtitulo = crearEstiloSubtitulo(libro);
            XSSFCellStyle estiloGrupo = crearEstiloCabecera(libro, AZUL_MEDIO);
            XSSFCellStyle estiloCabecera = crearEstiloCabecera(libro, AZUL_OSCURO);
            XSSFCellStyle[] estiloTexto = {crearEstiloDatos(libro, null, false), crearEstiloDatos(libro, null, true)};
            XSSFCellStyle[] estiloEntero = {crearEstiloDatos(libro, "0", false), crearEstiloDatos(libro, "0", true)};
            XSSFCellStyle[] estiloNumero = {crearEstiloDatos(libro, "#,##0.00", false), crearEstiloDatos(libro, "#,##0.00", true)};
            XSSFCellStyle[] estiloPrecio = {crearEstiloDatos(libro, "#,##0.000000", false), crearEstiloDatos(libro, "#,##0.000000", true)};
            XSSFCellStyle estiloTextoTotal = crearEstiloTotal(libro, null);
            XSSFCellStyle estiloNumeroTotal = crearEstiloTotal(libro, "#,##0.00");

            List<ColumnaCostoDTO> columnas = reporte.getColumnas();
            int ultimaColumna = COLUMNAS_FIJAS + columnas.size();

            int numFila = 0;

            Row filaTitulo = hoja.createRow(numFila++);
            filaTitulo.setHeightInPoints(24);
            escribir(filaTitulo, 0, "CONTROL DE INGRESOS", estiloTitulo);
            for (int i = 1; i <= ultimaColumna; i++) {
                escribir(filaTitulo, i, "", estiloTitulo);
            }
            hoja.addMergedRegion(new CellRangeAddress(0, 0, 0, ultimaColumna));

            Row filaRango = hoja.createRow(numFila++);
            escribir(filaRango, 0, descripcionRango(reporte), estiloSubtitulo);
            for (int i = 1; i <= ultimaColumna; i++) {
                escribir(filaRango, i, "", estiloSubtitulo);
            }
            hoja.addMergedRegion(new CellRangeAddress(1, 1, 0, ultimaColumna));

            numFila++; // fila en blanco

            // Cabecera de dos niveles: arriba la entidad (Petroecuador / Ministerio)
            // agrupando sus costos, abajo el nombre del costo con su cuenta contable.
            int filaGrupos = numFila++;
            int filaColumnas = numFila++;
            Row filaCabeceraGrupos = hoja.createRow(filaGrupos);
            Row filaCabecera = hoja.createRow(filaColumnas);
            filaCabeceraGrupos.setHeightInPoints(18);
            filaCabecera.setHeightInPoints(32);

            String[] fijas = {"#", "Nº Factura", "F. Embarque", "F. Depósito", "Compradora", "Contrato",
                    "Buque", "Producto", "Distribución", "Volumen", "Precio US$/bl", "Valor embarque"};
            for (int i = 0; i < fijas.length; i++) {
                escribir(filaCabeceraGrupos, i, fijas[i], estiloCabecera);
                escribir(filaCabecera, i, "", estiloCabecera);
                hoja.addMergedRegion(new CellRangeAddress(filaGrupos, filaColumnas, i, i));
            }

            int col = fijas.length;
            for (Map.Entry<String, List<ColumnaCostoDTO>> grupo : reporte.getColumnasPorEntidad().entrySet()) {
                int inicio = col;
                for (ColumnaCostoDTO columna : grupo.getValue()) {
                    escribir(filaCabeceraGrupos, col, "", estiloGrupo);
                    escribir(filaCabecera, col, columna.getNombreCosto() + "\n" + columna.getNumeroCuenta(), estiloCabecera);
                    col++;
                }
                escribir(filaCabeceraGrupos, inicio, "COSTOS " + grupo.getKey(), estiloGrupo);
                if (col - 1 > inicio) {
                    hoja.addMergedRegion(new CellRangeAddress(filaGrupos, filaGrupos, inicio, col - 1));
                }
            }

            escribir(filaCabeceraGrupos, col, "Total costos", estiloCabecera);
            escribir(filaCabecera, col, "", estiloCabecera);
            hoja.addMergedRegion(new CellRangeAddress(filaGrupos, filaColumnas, col, col));

            int correlativo = 1;
            for (ControlIngresoFilaDTO fila : reporte.getFilas()) {
                int z = correlativo % 2 == 0 ? 1 : 0; // filas alternadas, para poder seguir la línea
                Row filaExcel = hoja.createRow(numFila++);
                int c = 0;
                escribir(filaExcel, c++, correlativo++, estiloEntero[z]);
                escribir(filaExcel, c++, texto(fila.getNumFactura()), estiloTexto[z]);
                escribir(filaExcel, c++, texto(fila.getFecEmbarque()), estiloTexto[z]);
                escribir(filaExcel, c++, texto(fila.getFecDeposito()), estiloTexto[z]);
                escribir(filaExcel, c++, texto(fila.getCompradora()), estiloTexto[z]);
                escribir(filaExcel, c++, texto(fila.getContrato()), estiloTexto[z]);
                escribir(filaExcel, c++, texto(fila.getBuque()), estiloTexto[z]);
                escribir(filaExcel, c++, texto(fila.getProducto()), estiloTexto[z]);
                escribir(filaExcel, c++, texto(fila.getDistribucion()), estiloTexto[z]);
                escribir(filaExcel, c++, fila.getVolumen() != null ? fila.getVolumen() : 0, estiloNumero[z]);
                escribir(filaExcel, c++, fila.getPrecio() != null ? fila.getPrecio() : 0, estiloPrecio[z]);
                escribir(filaExcel, c++, fila.getValorEmbarque(), estiloNumero[z]);
                for (ColumnaCostoDTO columna : columnas) {
                    escribir(filaExcel, c++, fila.getCosto(columna.getClave()), estiloNumero[z]);
                }
                escribir(filaExcel, c, fila.getTotalCostos(), estiloNumero[z]);
            }

            Row filaTotales = hoja.createRow(numFila);
            filaTotales.setHeightInPoints(18);
            escribir(filaTotales, 0, "TOTAL", estiloTextoTotal);
            for (int i = 1; i <= 8; i++) {
                escribir(filaTotales, i, "", estiloTextoTotal);
            }
            hoja.addMergedRegion(new CellRangeAddress(numFila, numFila, 0, 8));

            int ct = 9;
            escribir(filaTotales, ct++, reporte.getTotalVolumen(), estiloNumeroTotal);
            escribir(filaTotales, ct++, "", estiloTextoTotal); // el precio no se suma
            escribir(filaTotales, ct++, reporte.getTotalValorEmbarque(), estiloNumeroTotal);
            for (ColumnaCostoDTO columna : columnas) {
                escribir(filaTotales, ct++, reporte.getTotalCosto(columna.getClave()), estiloNumeroTotal);
            }
            escribir(filaTotales, ct, reporte.getTotalCostos(), estiloNumeroTotal);

            ajustarAnchos(hoja, ultimaColumna);
            // Se congelan las cabeceras y las dos primeras columnas (# y Nº Factura)
            // para no perder de vista a qué factura pertenece cada costo.
            hoja.createFreezePane(2, filaColumnas + 1);
            hoja.setAutoFilter(new CellRangeAddress(filaColumnas, numFila - 1, 0, ultimaColumna));
            prepararImpresion(hoja, filaGrupos, filaColumnas);

            libro.write(salida);
        }
    }

    private void ajustarAnchos(XSSFSheet hoja, int ultimaColumna) {
        for (int i = 0; i <= ultimaColumna; i++) {
            hoja.autoSizeColumn(i);
            // autoSizeColumn mide el texto de la cabecera completo y deja columnas
            // absurdamente anchas, así que se acota a un rango legible.
            int ancho = hoja.getColumnWidth(i) + 512;
            hoja.setColumnWidth(i, Math.max(ANCHO_MINIMO, Math.min(ANCHO_MAXIMO, ancho)));
        }
    }

    private void prepararImpresion(XSSFSheet hoja, int filaGrupos, int filaColumnas) {
        hoja.setRepeatingRows(new CellRangeAddress(filaGrupos, filaColumnas, -1, -1));
        hoja.setFitToPage(true);
        PrintSetup impresion = hoja.getPrintSetup();
        impresion.setLandscape(true);
        impresion.setFitWidth((short) 1);
        impresion.setFitHeight((short) 0);
    }

    private String descripcionRango(ControlIngresoReporteDTO reporte) {
        String desde = reporte.getDesde() != null && !reporte.getDesde().isEmpty() ? reporte.getDesde() : "inicio";
        String hasta = reporte.getHasta() != null && !reporte.getHasta().isEmpty() ? reporte.getHasta() : "hoy";
        return "Facturas aprobadas entre " + desde + " y " + hasta;
    }

    private void escribir(Row fila, int columna, String texto, XSSFCellStyle estilo) {
        Cell celda = fila.createCell(columna);
        celda.setCellValue(texto);
        celda.setCellStyle(estilo);
    }

    private void escribir(Row fila, int columna, double valor, XSSFCellStyle estilo) {
        Cell celda = fila.createCell(columna);
        celda.setCellValue(valor);
        celda.setCellStyle(estilo);
    }

    private String texto(String valor) {
        return valor != null ? valor : "";
    }

    private XSSFCellStyle crearEstiloTitulo(XSSFWorkbook libro) {
        XSSFFont fuente = libro.createFont();
        fuente.setBold(true);
        fuente.setFontHeightInPoints((short) 14);
        fuente.setColor(new XSSFColor(AZUL_OSCURO, null));

        XSSFCellStyle estilo = libro.createCellStyle();
        estilo.setFont(fuente);
        estilo.setVerticalAlignment(VerticalAlignment.CENTER);
        return estilo;
    }

    private XSSFCellStyle crearEstiloSubtitulo(XSSFWorkbook libro) {
        XSSFFont fuente = libro.createFont();
        fuente.setFontHeightInPoints((short) 10);
        fuente.setColor(new XSSFColor(AZUL_MEDIO, null));

        XSSFCellStyle estilo = libro.createCellStyle();
        estilo.setFont(fuente);
        return estilo;
    }

    private XSSFCellStyle crearEstiloCabecera(XSSFWorkbook libro, byte[] fondo) {
        XSSFFont fuente = libro.createFont();
        fuente.setBold(true);
        fuente.setFontHeightInPoints((short) 9);
        fuente.setColor(new XSSFColor(new byte[]{(byte) 255, (byte) 255, (byte) 255}, null));

        XSSFCellStyle estilo = libro.createCellStyle();
        estilo.setFont(fuente);
        estilo.setFillForegroundColor(new XSSFColor(fondo, null));
        estilo.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        estilo.setAlignment(HorizontalAlignment.CENTER);
        estilo.setVerticalAlignment(VerticalAlignment.CENTER);
        estilo.setWrapText(true); // el nombre del costo y su cuenta van en dos líneas
        aplicarBordes(estilo);
        return estilo;
    }

    private XSSFCellStyle crearEstiloDatos(XSSFWorkbook libro, String formato, boolean alterna) {
        XSSFCellStyle estilo = libro.createCellStyle();
        if (formato != null) {
            estilo.setDataFormat(libro.createDataFormat().getFormat(formato));
            estilo.setAlignment(HorizontalAlignment.RIGHT);
        }
        if (alterna) {
            estilo.setFillForegroundColor(new XSSFColor(GRIS_FILA, null));
            estilo.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        }
        estilo.setVerticalAlignment(VerticalAlignment.CENTER);
        aplicarBordes(estilo);
        return estilo;
    }

    private XSSFCellStyle crearEstiloTotal(XSSFWorkbook libro, String formato) {
        XSSFFont fuente = libro.createFont();
        fuente.setBold(true);
        fuente.setColor(new XSSFColor(AZUL_OSCURO, null));

        XSSFCellStyle estilo = libro.createCellStyle();
        estilo.setFont(fuente);
        estilo.setFillForegroundColor(new XSSFColor(GRIS_FILA, null));
        estilo.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        estilo.setVerticalAlignment(VerticalAlignment.CENTER);
        if (formato != null) {
            estilo.setDataFormat(libro.createDataFormat().getFormat(formato));
            estilo.setAlignment(HorizontalAlignment.RIGHT);
        }
        aplicarBordes(estilo);
        estilo.setBorderTop(BorderStyle.DOUBLE);
        return estilo;
    }

    private void aplicarBordes(XSSFCellStyle estilo) {
        XSSFColor borde = new XSSFColor(GRIS_BORDE, null);
        estilo.setBorderTop(BorderStyle.THIN);
        estilo.setBorderBottom(BorderStyle.THIN);
        estilo.setBorderLeft(BorderStyle.THIN);
        estilo.setBorderRight(BorderStyle.THIN);
        estilo.setTopBorderColor(borde);
        estilo.setBottomBorderColor(borde);
        estilo.setLeftBorderColor(borde);
        estilo.setRightBorderColor(borde);
    }
}
