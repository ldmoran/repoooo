package com.finanzas.gestionfinanzas.service.impl;

import com.finanzas.gestionfinanzas.entity.FacturasBDD;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

// Devuelve al ERP el estado del reparto de cada factura, escribiéndolo como texto
// en RA_CUSTOMER_TRX_ALL.GLOBAL_ATTRIBUTE8 (columna libre reservada para esto).
// Se identifica la factura por CUSTOMER_TRX_ID y se actualiza ÚNICAMENTE esa
// columna: ningún otro dato de la factura del ERP se toca.
//
// Va contra el datasource "apps" (primary), que es una base distinta a la nuestra,
// así que es una transacción aparte de la que guarda en nuestras tablas.
@Service
public class EstadoFacturaErpService {

    private static final String SQL_ACTUALIZAR =
            "UPDATE APPS.RA_CUSTOMER_TRX_ALL SET GLOBAL_ATTRIBUTE8 = :estado WHERE CUSTOMER_TRX_ID = :customerTrxId";

    @PersistenceContext(unitName = "primary")
    private EntityManager entityManager;

    @Transactional("primaryTransactionManager")
    public void sincronizar(FacturasBDD factura) {
        if (factura == null || factura.getCustomerTrxId() == null) {
            return;
        }

        entityManager.createNativeQuery(SQL_ACTUALIZAR)
                .setParameter("estado", etiquetaEstado(factura))
                .setParameter("customerTrxId", factura.getCustomerTrxId())
                .executeUpdate();
    }

    // El nombre completo del estado. Se distingue según haya pasado o no por el
    // flujo de rondas (ESTADO_PARCIAL), porque no significan lo mismo:
    //   - Repartida por rondas: "Parcial" mientras quede saldo, "Completado" al
    //     cerrarse la última ronda.
    //   - Repartida de una sola vez: "Distribuido", sin pasos intermedios.
    public String etiquetaEstado(FacturasBDD factura) {
        if ("P".equals(factura.getEstadoParcial())) {
            return "Parcial";
        }
        if ("C".equals(factura.getEstadoParcial())) {
            return "Completado";
        }

        Double faltante = factura.getVolumenFaltante();
        if (faltante != null && Math.abs(faltante) < 0.01) {
            return "Distribuido";
        }

        if ("A".equalsIgnoreCase(factura.getEstado())) {
            return "Aprobada";
        }

        return "Registrada";
    }
}
