package com.finanzas.gestionfinanzas.service.impl;

import com.finanzas.gestionfinanzas.entity.FactFlujoCaja;
import com.finanzas.gestionfinanzas.repository.apps.FactFlujoCajaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

// XXOCS_AR_FACT_FLUJO_CAJA vive en la BD de EBS (datasource "apps") sin autonumerado
// configurado en su ID, así que esta app se lo asigna: MAX(ID)+1 sobre la misma tabla,
// consultado una sola vez por lote e incrementado en memoria para que las filas del
// mismo "Enviar a EBS" no choquen entre sí.
@Service
public class FactFlujoCajaService {

    private final FactFlujoCajaRepository factFlujoCajaRepository;

    public FactFlujoCajaService(FactFlujoCajaRepository factFlujoCajaRepository) {
        this.factFlujoCajaRepository = factFlujoCajaRepository;
    }

    @Transactional("primaryTransactionManager")
    public void guardarLote(List<FactFlujoCaja> filas) {
        if (filas == null || filas.isEmpty()) {
            return;
        }

        long siguienteId = factFlujoCajaRepository.obtenerMaxId() + 1;
        for (FactFlujoCaja fila : filas) {
            fila.setId(siguienteId++);
        }

        factFlujoCajaRepository.saveAll(filas);
    }
}
