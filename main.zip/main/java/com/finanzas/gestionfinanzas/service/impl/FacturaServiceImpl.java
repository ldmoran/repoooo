package com.finanzas.gestionfinanzas.service.impl;

import com.finanzas.gestionfinanzas.entity.Factura;
import com.finanzas.gestionfinanzas.repository.apps.FacturaRepository;
import com.finanzas.gestionfinanzas.service.FacturaService;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;


import java.util.Collections;
import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;

@Service
public class FacturaServiceImpl implements FacturaService {

    private final FacturaRepository facturaRepository;

    public FacturaServiceImpl(FacturaRepository facturaRepository) {
        this.facturaRepository = facturaRepository;
    }

    @Override
    public Page<Factura> listarFacturas(Pageable pageable) {
        return facturaRepository.findFacturas(pageable);
    }
    @Override
    public List<Factura> buscarTodasPorRangoEmbarque(String ruc,
                                        String numFactura,
                                        String fecEmbarqueInicio,
                                        String fecEmbarqueFin,
                                        String fecDeposito,
                                        String fecFactura) {
        return facturaRepository.buscarTodasPorRangoEmbarque(fecEmbarqueInicio, fecEmbarqueFin, ruc, numFactura, fecDeposito, fecFactura);
    }

    @Override
    public List<Factura> buscarTodasPorRangoDeposito(String ruc,
                                        String numFactura,
                                        String fecDepositoInicio,
                                        String fecDepositoFin,
                                        String fecFactura) {
        return facturaRepository.buscarTodasPorRangoDeposito(fecDepositoInicio, fecDepositoFin, ruc, numFactura, fecFactura);
    }

}