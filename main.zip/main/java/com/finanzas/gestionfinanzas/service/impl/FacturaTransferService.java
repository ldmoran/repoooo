package com.finanzas.gestionfinanzas.service.impl;

import com.finanzas.gestionfinanzas.entity.Factura;
import com.finanzas.gestionfinanzas.entity.FacturasBDD;
import com.finanzas.gestionfinanzas.repository.bdd.FacturasBDDRepository;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
public class FacturaTransferService {

    private final FacturasBDDRepository facturasBDDRepository;
    private final AuditoriaSessionService auditoriaSessionService;

    public FacturaTransferService(FacturasBDDRepository facturasBDDRepository,
                                  AuditoriaSessionService auditoriaSessionService) {
        this.facturasBDDRepository = facturasBDDRepository;
        this.auditoriaSessionService = auditoriaSessionService;
    }

    @Transactional("secondTransactionManager")
    public void guardarEnBDD(Factura factura) {
        if (factura == null) {
            return;
        }

        if (factura.getCustomerTrxId() != null && facturasBDDRepository.existsByCustomerTrxId(factura.getCustomerTrxId())) {
            return;
        }

        if (factura.getNumFactura() != null && factura.getRuc() != null &&
                facturasBDDRepository.existsByNumFacturaAndRuc(factura.getNumFactura(), factura.getRuc())) {
            return;
        }

        // Se marca el usuario recién aquí: si la factura ya existía se sale antes y
        // no hace falta tocar la sesión de Oracle en cada una de las que se revisan.
        auditoriaSessionService.activarUsuarioActual();

        FacturasBDD nueva = new FacturasBDD();
        nueva.setCustomerTrxId(factura.getCustomerTrxId());
        nueva.setNumFactura(truncar(factura.getNumFactura(), 50));
        nueva.setFecEmbarque(truncar(factura.getFecEmbarque(), 20));// convertir si usas String → LocalDate
        nueva.setFecDeposito(truncar(factura.getFecDeposito(), 20));
        nueva.setRuc(truncar(factura.getRuc(), 20));
        nueva.setCompania(truncar(factura.getCompania(), 100));
        nueva.setContrato(truncar(factura.getContrato(), 100));
        nueva.setBuque(truncar(factura.getBuque(), 100));
        nueva.setCantidad(factura.getCantidad());
        nueva.setPrecio(factura.getPrecio());
        nueva.setSubtotal(factura.getSubtotal());
        nueva.setDescripcion(truncar(factura.getDescripcion(), 200));
        nueva.setFecFactura(truncar(factura.getFecFactura(), 20));
        nueva.setIdDistribucion(0L); // valor por defecto
        nueva.setEstado("R"); // Registrada por defecto; pasa a "A" (Aprobada) al guardar sus costos

        // Primera ronda de esta factura: el volumen a distribuir es toda la CANTIDAD.
        Double volumenInicial = factura.getCantidad() != null ? factura.getCantidad().doubleValue() : null;
        nueva.setVolumenTotal(volumenInicial);
        nueva.setVolumenDistribuido(0.0);
        nueva.setVolumenFaltante(volumenInicial);
        nueva.setSecuencia(0); // ronda activa/pendiente, aún no Aprobada
        nueva.setFechaModificacion(LocalDateTime.now());

        facturasBDDRepository.save(nueva);
    }

    // La vista externa a veces trae texto más largo del que soportan las columnas
    // de nuestra tabla FACTURAS (ej. DESCRIPCION de 206 caracteres en una columna
    // VARCHAR2(200)); se recorta para no reventar el INSERT.
    private String truncar(String valor, int maxLength) {
        if (valor == null || valor.length() <= maxLength) {
            return valor;
        }
        return valor.substring(0, maxLength);
    }
}
