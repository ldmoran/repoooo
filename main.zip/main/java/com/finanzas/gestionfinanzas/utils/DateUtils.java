package com.finanzas.gestionfinanzas.utils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DateUtils {
    public static String formatearFecha(String fecha, String formatoEntrada, String formatoSalida) {
        String fechaFormateada = null;

        if (fecha != null && !fecha.isEmpty()) {
            DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern(formatoEntrada);
            DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern(formatoSalida);

            LocalDate fechaConFormato = LocalDate.parse(fecha, inputFormatter);
            fechaFormateada = fechaConFormato.format(outputFormatter);
        }

        return fechaFormateada;
    }

    public static String formatearFechaHora(String fecha, String formatoEntrada, String formatoSalida) {
        String fechaFormateada = null;

        if (fecha != null && !fecha.isEmpty()) {
            DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern(formatoEntrada);
            DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern(formatoSalida);

            LocalDateTime fechaConFormato = LocalDateTime.parse(fecha, inputFormatter);
            fechaFormateada = fechaConFormato.format(outputFormatter);
        }

        return fechaFormateada;
    }
}
