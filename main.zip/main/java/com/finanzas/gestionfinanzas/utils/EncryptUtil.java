package com.finanzas.gestionfinanzas.utils;

import com.finanzas.gestionfinanzas.config.AppProperties;
import org.springframework.stereotype.Component;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

@Component
public class EncryptUtil {

    private final AppProperties appProperties;

    private static final String ALGORITHM = "AES";
    private static final String TRANSFORMATION = "AES/CBC/PKCS5Padding";

    public EncryptUtil(AppProperties appProperties) {
        this.appProperties = appProperties;
    }

    public String encriptar(String valor) throws Exception {
        String clave = appProperties.getSeguridad().getCipherClave();
        String vector = appProperties.getSeguridad().getCipherVector();

        byte[] keyBytes = clave.getBytes(StandardCharsets.UTF_8);
        byte[] ivBytes = vector.getBytes(StandardCharsets.UTF_8);

        SecretKeySpec secretKey = new SecretKeySpec(keyBytes, ALGORITHM);
        IvParameterSpec ivSpec = new IvParameterSpec(ivBytes);

        Cipher cipher = Cipher.getInstance(TRANSFORMATION);

        cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivSpec);

        byte[] encrypted = cipher.doFinal(valor.getBytes(StandardCharsets.UTF_8));

        return Base64.getEncoder().encodeToString(encrypted);
    }
}
