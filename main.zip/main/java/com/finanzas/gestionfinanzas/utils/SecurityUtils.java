package com.finanzas.gestionfinanzas.utils;


import com.finanzas.gestionfinanzas.auth.dto.response.AuthResponseDTO;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

public class SecurityUtils {
    private SecurityUtils() {
    }

    public static AuthResponseDTO getUsuarioActual() {

        Authentication authentication =
                SecurityContextHolder.getContext()
                        .getAuthentication();

        if (authentication == null) {
            return null;
        }

        Object principal =
                authentication.getPrincipal();

        if (principal instanceof AuthResponseDTO) {
            return (AuthResponseDTO) principal;
        }

        return null;
    }
}
