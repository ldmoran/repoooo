document.addEventListener('DOMContentLoaded', function () {
  const modalEl = document.getElementById('distribucionesModal');
  if (!modalEl) return;
  const modalBody = document.getElementById('distribucionesModalBody');
  const bsModal = new bootstrap.Modal(modalEl);

  // lee el context path desde el meta tag
  const meta = document.querySelector('meta[name="context-path"]');
  const base = meta ? meta.getAttribute('content') : '';

  // selector para los botones (ajusta si usas otra clase)
  document.querySelectorAll('.icon-eye, .ver-distribuciones').forEach(btn => {
    btn.addEventListener('click', function () {
      const id = this.getAttribute('data-id');
      if (!id) {
        modalBody.innerHTML = '<div class="text-danger p-3">ID no disponible.</div>';
        bsModal.show();
        return;
      }
      modalBody.innerHTML = '<div class="text-center py-4">Cargando...</div>';

      // construye la URL con el context path
      const url = base + `/facturas/${id}/distribuciones-fragment`;

      fetch(url, { method: 'GET' })
        .then(resp => {
          if (!resp.ok) throw new Error('HTTP ' + resp.status);
          return resp.text();
        })
        .then(html => {
          modalBody.innerHTML = html;
          bsModal.show();
        })
        .catch(err => {
          console.error('Error cargando distribuciones:', err);
          modalBody.innerHTML = '<div class="text-danger p-3">No se pudo cargar. Intenta de nuevo.</div>';
          bsModal.show();
        });
    });
  });
});
